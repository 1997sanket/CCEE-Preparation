# Join Assignment -- SALES.
```SQL
SELECT o.onum, c.cname
FROM ORDERS o INNER JOIN CUSTOMERS c ON c.cnum = o.cnum;

SELECT o.onum, c.cname, s.sname
FROM ORDERS o
INNER JOIN CUSTOMERS c ON c.cnum = o.cnum
INNER JOIN SALESPEOPLE s ON s.snum = o.snum;

SELECT c.cname, s.sname, s.comm
FROM CUSTOMERS c INNER JOIN SALESPEOPLE s ON c.snum = s.snum
WHERE s.comm > 0.12;

SELECT o.onum, s.sname, o.amt, s.comm, o.amt * s.comm
FROM ORDERS o
INNER JOIN SALESPEOPLE s ON o.snum = s.snum
INNER JOIN CUSTOMERS c ON o.cnum = c.cnum
WHERE c.rating > 100;

SELECT s1.sname, s2.sname, s1.city
FROM SALESPEOPLE s1
INNER JOIN SALESPEOPLE s2 ON s1.city = s2.city
WHERE s1.snum > s2.snum;

SELECT c1.cname, c1.city, c1.rating
FROM CUSTOMERS c1
INNER JOIN CUSTOMERS c2 ON c1.rating = c2.rating
WHERE c2.cname = 'Hoffman';

SELECT cname, city, rating FROM CUSTOMERS
WHERE rating = (SELECT rating FROM CUSTOMERS WHERE cname = 'Hoffman');
```

# Views
* Two types of views:
	- Complex views: View contains group by, joins or sub-queries.
		- Cannot perform DML operations.
	- Simple views: No complex view.
		- Can perform DQL & DML operations.

* Views are internally simply SELECT statements and no separate copy of data is maintained. Whenever a query is fired on a view, it is clubbed with the SELECT statement of view creations and then db engine creates a plan for execution.

* Applications:
	- Data security: can give restricted to the data to users.
	- Code security: hide table create statement from users.
	- Simplification of complex queries.

```SQL
SHOW CREATE TABLE SALESPEOPLE;

CREATE VIEW ORDERS_WO_AMT AS
SELECT onum, odate, cnum, snum FROM ORDERS;

GRANT SELECT, INSERT ON ORDERS_WO_AMT TO dac@localhost;
-- should be done by root user if current doesn't have GRANT OPTION

SELECT * FROM ORDERS_WO_AMT;

INSERT INTO ORDERS_WO_AMT VALUES (1234, '2019-02-25', 1, 2);

CREATE VIEW SALESPEOPLE_LT_12 AS
SELECT * FROM SALESPEOPLE WHERE comm <= 0.12;

SELECT * FROM SALESPEOPLE_LT_12;

CREATE VIEW ORDERS_DETAILS AS
SELECT o.onum, o.amt, o.odate, o.cnum, o.snum, c.cname, c.city ccity, c.rating crating, s.sname, s.city scity, s.comm scomm
FROM ORDERS o
INNER JOIN CUSTOMERS c ON c.cnum = o.cnum
INNER JOIN SALESPEOPLE s ON s.snum = o.snum;

CREATE VIEW ORDERS_SUMMARY AS
SELECT odate, COUNT(onum), SUM(amt)
FROM ORDERS GROUP BY odate;

SELECT * FROM ORDERS_SUMMARY;

DROP VIEW ORDERS_SUMMARY;

CREATE VIEW ORDERS_SUMMARY AS
SELECT odate, COUNT(onum) cnt, SUM(amt) total
FROM ORDERS GROUP BY odate;

SELECT odate, cnt FROM ORDERS_SUMMARY;

INSERT INTO ORDERS_SUMMARY VALUES ('2019-02-25', 10, 1000000);
```

# ALTER statement
* Used to change schema of a table.
* However this is strictly prohibited in production. It decrease efficiency of storage & computation.
* Types of changes:
	- Direct changes - changing struct/layout of table.
	- Indirect changes - changing size of some col, ...

### Direct changes:
```SQL
RENAME TABLE oldname TO newname;

ALTER TABLE EMP ADD COLUMN bdate DATE;

ALTER TABLE EMP MODIFY COLUMN ename VARCHAR(80);

ALTER TABLE EMP DROP COLUMN bdate;
```

### Indirect changes:
```SQL
ALTER TABLE EMP MODIFY COLUMN job VARCHAR(20);

ALTER TABLE EMP MODIFY COLUMN sal DOUBLE;

CREATE TABLE EMP2 AS SELECT * FROM EMP;

CREATE TABLE EMP3 AS SELECT * FROM EMP LIMIT 0;

--
CREATE TABLE TEMP AS SELECT empno, ename, job, mgr, hire, sal, deptno, comm FROM EMP;

DROP TABLE EMP;

RENAME TABLE TEMP TO EMP;
```

# Constraints
* Apply restrictions on values which can be inserted/updated in that column.
* Types of Constraints
	- Primary Key
	- Foreign Key
	- Unique Key
	- Not Null
	- Check Constraints

### Primary Key
* Unique key that identifies/represent the record/row.
* Primary key is always unique (cannot be duplicated).
* Primary key cannot be null.
* e.g. Contact details --
	- Columns: Name, Address, Mobile, Email (PK).
```SQL
CREATE TABLE CONTACTS(
name VARCHAR(40),
address VARCHAR(100),
mobile CHAR(14),
email CHAR(40) PRIMARY KEY
);

--OR

CREATE TABLE CONTACTS(
name VARCHAR(40),
address VARCHAR(100),
mobile CHAR(14),
email CHAR(40),
PRIMARY KEY (email)
);

SHOW INDEXES FROM CONTACTS;

DESC CONTACTS;
```	
* Internally Unique index is created on PK field.

* e.g. Students details --
	- Columns: Std, Roll, Name, Marks.
* Sometimes PK can be combination of multiple fields -- Composite Primary Key.

``` SQL
CREATE TABLE STUDENTS(
std INT,
roll INT,
name VARCHAR(40),
marks DOUBLE,
PRIMARY KEY (std, roll)
);
```
* Internally composite index created on PK fields.

* e.g. Employee details:
	- Columns: empno, name, sal, hiredate, comm
``` SQL
CREATE TABLE employees(
empno INT PRIMARY KEY,
name VARCHAR(40),
sal DOUBLE,
comm DOUBLE,
hiredate DATE,
);

-- OR

CREATE TABLE employees(
empno INT,
name VARCHAR(40),
sal DOUBLE,
comm DOUBLE,
hiredate DATE,
PRIMARY KEY(empno)
);
```
* Adding extra column as PK is referred as "Surrogate PK".

``` SQL
CREATE TABLE employees(
empno INT AUTO_INCREMENT,
name VARCHAR(40),
sal DOUBLE,
comm DOUBLE,
hiredate DATE,
PRIMARY KEY(empno)
);

INSERT INTO employees (name, sal, hiredate) VALUES ('A', 10000, NOW());
INSERT INTO employees (name, sal, hiredate) VALUES ('B', 10000, NOW());

SELECT * FROM employees;
```

* PK can also be added later on dropped.

```SQL
ALTER TABLE DEPT ADD PRIMARY KEY (deptno);

ALTER TABLE DEPT AUTO_INCREMENT = 123;

ALTER TABLE employees DROP PRIMARY KEY (empno);
```

### Unique Key
* Column can have only unique values (no duplicates allowed).
* Similar to primary key, but differ in following:
	- One table can have multiple unique keys.
	- Unique columns can contain null values.
* Internally it creates unique index on that column.

```SQL
CREATE TABLE CONTACTS(
name VARCHAR(40),
address VARCHAR(100),
mobile CHAR(14) UNIQUE,
email CHAR(40) PRIMARY KEY
);
```

### Foreign Key Constraint
* Related to table relations.
* A column in a table that represent relation with another table. Typically it is mapped to PK of another table.
* In case another table having composite PK, foreign key will also contain multiple columns.
* Foreign key is part of child table -> Primary key is part of parent table.
* If no parent row is present, then corresponding child rows cannot be inserted.

```SQL
CREATE TABLE DEPT
(
deptno INT,
dname VARCHAR(20),
PRIMARY KEY(deptno)
);
INSERT INTO DEPT VALUES (10, 'DEV');
INSERT INTO DEPT VALUES (20, 'QA');
INSERT INTO DEPT VALUES (30, 'OPS');
INSERT INTO DEPT VALUES (40, 'ACC');

CREATE TABLE EMP
(
empno INT,
ename VARCHAR(20),
deptno INT,
PRIMARY KEY (empno),
FOREIGN KEY (deptno) REFERENCES DEPT(deptno)
);
INSERT INTO EMP VALUES (1, 'Amit', 10);
INSERT INTO EMP VALUES (2, 'Rahul', 10);
INSERT INTO EMP VALUES (3, 'Nilesh', 20);

INSERT INTO DEPT VALUES (50, 'MGR');

INSERT INTO EMP VALUES (4, 'Nitin', 50);
INSERT INTO EMP VALUES (5, 'Sarang', 50);
```

* When FK constraints are enabled, DML operations are slower.
* While migrating db, to improve speed of db transfer these constraints can be disabled temporarily.

```SQL
SELECT @@foreign_key_checks;

SET @@foreign_key_checks = 0; -- disable fk checks

SELECT @@foreign_key_checks;

SET @@foreign_key_checks = 1; -- enable fk checks
```

* When FK constraints are enabled, we cannot delete parent entities. Because it will make child entities orphan.
* However, MySQL allows auto deleting child entities along with parent entities. This is done by mentioning "ON CASCADE DELETE" while table creation.

```SQL
DROP TABLE EMP;

CREATE TABLE EMP
(
empno INT,
ename VARCHAR(20),
deptno INT,
PRIMARY KEY (empno),
FOREIGN KEY (deptno) REFERENCES DEPT(deptno) ON DELETE CASCADE
);

DELETE FROM DEPT WHERE deptno = 50;
```

* When FK constraints are enabled, we cannot update parent entity PK. Because it will make child entities orphan.
* However, MySQL allows auto updating child entity foreign key fields along with parent entities. This is done by mentioning "ON CASCADE UPDATE" while table creation.

```SQL
DROP TABLE EMP;

CREATE TABLE EMP
(
empno INT,
ename VARCHAR(20),
deptno INT,
PRIMARY KEY (empno),
FOREIGN KEY (deptno) REFERENCES DEPT(deptno) ON UPDATE CASCADE
);

INSERT INTO EMP VALUES (1, 'Amit', 10);
INSERT INTO EMP VALUES (2, 'Rahul', 10);
INSERT INTO EMP VALUES (3, 'Nilesh', 20);

UPDATE DEPT SET deptno=100 WHERE deptno=10;
```

```SQL
CREATE TABLE EMP
(
empno INT,
ename VARCHAR(20),
deptno INT,
PRIMARY KEY (empno),
FOREIGN KEY (deptno) REFERENCES DEPT(deptno) ON UPDATE CASCADE ON DELELE CASCADE
);
```

### NOT NULL
* Null values are not allowed in column.
* However duplicates are allowed.
* Always column level constraint.

```SQL
CREATE TABLE EMP
(
empno INT,
ename VARCHAR(20) NOT NULL,
deptno INT NOT NULL,
PRIMARY KEY (empno)
);
```

### CHECK constraint
* Check validity of the data e.g. name must be in cap case, age must be greater than 1 or sal+comm must be greater than 6000.
* Till MySQL 8.0.15, CHECK constraints are parsed, but not applied.
* MySQL 8.0.16 is first mysql version that supports check constraint.

```SQL
CREATE TABLE EMP123
(
empno INT,
ename VARCHAR(40) CHECK (ename = UPPER(ename)),
job VARCHAR(20),
mgr INT,
sal DOUBLE NOT NULL CHECK (sal BETWEEN 5000 AND 10000),
comm DOUBLE,
deptno INT,
PRIMARY KEY (empno),
FOREIGN KEY (deptno) REFERENCES DEPT(deptno),
FOREIGN KEY (mgr) REFERENCES EMP(empno),
CHECK(sal + comm > 6000)
);

SELECT @@version;
```

# Transactions
* Transaction is set of DML queries that is to be executed as a single unit. If any query from tx is failed, rest of queries effect should be discarded.
* Basic Tx commands:
	- START TRANSACTION -- start new tx.
	- COMMIT -- make changes in current tx permanent in db.
	- ROLLBACK -- discard changes done in current tx.
	- SAVEPOINT
* Transaction is completed when COMMIT/ROLLBACK is done.
* For next set of DML ops, we should create new tx.

```SQL
START TRANSACTION;

DELETE FROM BOOKS WHERE id=2001;

COMMIT;
```

```SQL
START TRANSACTION;

DELETE FROM BOOKS;

ROLLBACK;
```

```SQL
START TRANSACTION;
query1;
query2;
SAVEPOINT a;

query3;
query4;
SAVEPOINT b;

query5;
query6;
-- 5 & 6 are wrong

ROLLBACK TO b;
-- changes after "b" are discarded i.e. 5 & 6.
```

```SQL
START TRANSACTION;
query1;
query2;
SAVEPOINT a;
query3;
query4;
SAVEPOINT b;
query5;
query6;
-- 5 & 6 are wrong

ROLLBACK TO a;
-- changes after "a" are discarded i.e. 3, 4, 5 & 6.
-- note that savepoint b is also discarded.
```

```SQL
START TRANSACTION;
query1;
query2;
SAVEPOINT a;
query3;
query4;
SAVEPOINT b;
query5;
query6;
-- 5 & 6 are wrong

ROLLBACK;
-- all changes in tx are discardedd i.e. query 1 to 6.
```

```SQL
START TRANSACTION;
query1;
query2;
SAVEPOINT a;
query3;
query4;
SAVEPOINT b;
query5;
query6;

COMMIT TO a; -- error
-- you cannot commit upto save point.
```

* Note that tx is set of DML queries.
* When any DDL query is executed in between the tx, current tx is automatically commited.

```SQL
START TRANSACTION;

INSERT INTO BOOKS VALUES (9001, 'Atlas Shrugged', 'Any Rand', 'Novell', 123.45);

INSERT INTO BOOKS VALUES (9002, 'The Fountainhead', 'Any Rand', 'Novell', 234.45);

DROP TABLE EMP3; -- DDL ??

SELECT * FROM BOOKS;

ROLLBACK;

```

* If client is closed before tx is commited/rollbacked, it is automatically rollbacked (in MySQL).

```SQL
START TRANSACTION;

INSERT INTO BOOKS VALUES (9005, 'Yugandhar', 'Satam', 'Novell', 345.56);

QUIT;
```

### Trasactions have ACID properties. By the end of transaction:
* A-Atomic:
	- All queries in Tx form one "unit".
	- It is not possible to commit/rollback partial tx.
* C-Consistent:
	- All clients should see the same data.
	- All data should be consistent -- no orphan records.
* I-Isolation:
	- All txs of all clients should be executed in isolated manner.
	- As if they are executed one after another.
	- If two tx are accessing same row, then db should make proper use of synchronization (locking) to ensure that data is not corrupted.
* D-Durable:
	- The db state must be saved in server disk, even in case of db crash.

