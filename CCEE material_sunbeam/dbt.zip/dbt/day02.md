# Db Logical layout

* Databases/Schemas
	- Schema is a logical container.
	- It stores tables, constraints, relations, procedures, functions, triggers, ...
	- For each new project create a separate schema.
	- This simplifies backup, restore, repair or other admin functionalities.
	- Two different dbs can have tables with same name.
	- Db can be created by db admin or any other user who have "CREATE" global permissions.
	
* Tables
	- Tables are always within some db/schema.
	- Organize data in terms of rows & columns.
	- Row -- represent one record.
	- Columns -- represents fields/attributes in the record.
	
# Db Physical layout
* Physical layout means how data is stored on server hard disk.
* This may change from vendor to vendor.
* In general,
	- Records/Rows are stored on server hard disk in scattered manner depending on available space.
	- Fields in a record are always consecutive.
* In MySQL,
	- The data is stored in "mysql data directory" i.e. /var/lib/mysql.
	- For each "database/schema" a separated directory is created.
	- For each "table" in "db/schema" a binary file is created.
	- In Linux, file names are case-sensitive and hence in MySQL on Linux table-names are case-sensitive.

# MySQL client:
```
cmd> mysql -u dac -p -- no db selected by default
cmd> mysql -u dac -p dacdb -- dacdb selected by default
```
# SQL
* SQL query must end with ";".
* SQL is case insensitive. But in MySQL on Linux table-names are case-sensitive.
* Different types of queries are supported:
	- DDL (Data Definition Language)
		- Related to structure of data
		- CREATE, ALTER, DESCRIBE, RENAME, ...
	- DML (Data Manipulation Language)
		- INSERT, UPDATE, DELETE
	- DQL (Data Query Language)
		- SELECT
	- DCL (Data Control Language)
		- Related to giving permissions to users.
		- GRANT, REVOKE, SHOW GRANTS, ...
	- TCL (Transaction Control Language)
		- Set of DML queries to be executed as single unit - transaction.
		- Either all queries in a transaction should be successful or should be discarded.
		- SAVEPOINT, COMMIT, ROLLBACK, ...
* In SQL queries, use numeric & boolean values directly; while strings, date & time must be enclosed in single quotes.

# Data Types
* CREATE TABLE table_name (col_name data_type, col_name data_type, col_name data_type, ...);
* Data types are classified in categories:
	- Numeric
	- Date & Time
	- String
	- Binary
	- Misc

# INSERT
* INSERT INTO table_name VALUES (v1, v2, v3);
* INSERT INTO table_name VALUES (v1, v2, v3), (v1, v2, v3), (v1, v2, v3);

```SQL
INSERT INTO STUDENTS (marks, roll, name) VALUES (32.30, 5, 'Soham');
INSERT INTO STUDENTS (roll, name) VALUES (6, 'Sakshi');
INSERT INTO STUDENTS (roll, name, marks) VALUES (7, 'Prisha', 34.56);

CREATE TABLE NEW_STUDENTS (roll INT, name VARCHAR(40), marks DOUBLE);

INSERT INTO NEW_STUDENTS SELECT * FROM STUDENTS;

DROP TABLE NEW_STUDENTS;

CREATE TABLE NEW_STUDENTS (name VARCHAR(40), roll INT, marks DOUBLE);

INSERT INTO NEW_STUDENTS SELECT name, roll, marks FROM STUDENTS;

INSERT INTO NEW_STUDENTS (roll, name, marks) SELECT * FROM STUDENTS;

DROP TABLE NEW_STUDENTS;

CREATE TABLE NEW_STUDENTS (roll INT, name VARCHAR(40));

INSERT INTO NEW_STUDENTS (roll, name) SELECT roll, name FROM STUDENTS;
```

# LOAD DATA
* This is "Extended SQL" in MySQL.
* Used to load data into table from "csv" file.
* This feature is allowed in MySQL 5.7 or below.
* This feature is restricted in MySQL 8.0+ for security reasons.

# SELECT query
* Basic SELECT, aliases, computed columns, order by, where clause & operators.
* SELECT with GROUP BY & HAVING.
* SELECT with sub-queries.
* SELECT with joins.

```SQL

DESCRIBE EMP;

SELECT * FROM EMP;
-- * represents all columns.

SELECT empno, ename, job, mgr, hire, sal, comm, deptno FROM EMP;

SELECT empno, ename, sal FROM EMP;

SELECT empno AS Id, ename AS `Employee Name`, sal Salary FROM EMP;

SELECT empno, ename, sal, sal * 0.20 FROM EMP;

SELECT empno, ename, sal, sal * 0.20 AS da FROM EMP;

SELECT empno, ename, sal, sal * 0.20 AS da, sal + sal * 0.20 AS `total sal` FROM EMP;

SELECT empno, ename, sal, comm FROM EMP;

SELECT empno, ename, sal, comm, sal + comm FROM EMP;

CREATE TABLE EMP2 (empno INT, ename VARCHAR(40), sal DECIMAL(8,2), da DECIMAL(8,2));

INSERT INTO EMP2 SELECT empno, ename, sal, sal * 0.20 FROM EMP;

DROP TABLE EMP2;

SELECT DISTINCT job from EMP;

SELECT DISTINCT deptno from EMP;

SELECT DISTINCT deptno, job from EMP;

SELECT * FROM EMP;

SELECT * FROM EMP LIMIT 5;

SELECT * FROM EMP LIMIT 3, 5;

SELECT * FROM EMP ORDER BY empno;

SELECT * FROM EMP ORDER BY ename;

SELECT * FROM EMP ORDER BY hire;

SELECT * FROM EMP ORDER BY sal DESC;

SELECT * FROM EMP ORDER BY deptno ASC;

SELECT * FROM EMP ORDER BY sal DESC LIMIT 1;

SELECT * FROM EMP ORDER BY sal DESC LIMIT 3;

SELECT * FROM EMP ORDER BY sal DESC LIMIT 2,1;

SELECT * FROM EMP ORDER BY deptno, job;

SELECT * FROM EMP ORDER BY job, deptno;

SELECT * FROM EMP ORDER BY deptno ASC, sal DESC;

SELECT * FROM EMP ORDER BY deptno, job, sal DESC;

SELECT ename, sal, sal * 0.20 FROM EMP ORDER BY sal * 0.20;

SELECT ename, sal, sal * 0.20 FROM EMP ORDER BY 3 DESC;
-- sort on 3rd column (computed column)

SELECT ename, sal, sal * 0.20 AS da FROM EMP ORDER BY da DESC;

SELECT * FROM EMP;


-- Relatioal Operators
SELECT * FROM EMP WHERE empno = 7900;

SELECT * FROM EMP WHERE empno != 7900;

SELECT * FROM EMP WHERE empno <> 7900;

SELECT * FROM EMP WHERE sal > 1500;

SELECT * FROM EMP WHERE sal >= 1500;

SELECT * FROM EMP WHERE sal < 1500;

SELECT * FROM EMP WHERE sal <= 1500;

SELECT * FROM EMP WHERE comm IS NULL;

SELECT * FROM EMP WHERE comm IS NOT NULL;

-- Logical Operators
SELECT * FROM EMP WHERE sal > 1000 AND sal < 3000;

SELECT * FROM EMP WHERE job = 'CLERK' OR job = 'SALESMAN';

SELECT * FROM EMP WHERE job != 'CLERK' AND job != 'SALESMAN';

SELECT * FROM EMP WHERE NOT (job = 'CLERK' OR job = 'SALESMAN');

-- BETWEEN operator
SELECT * FROM EMP WHERE sal > 1100 AND sal < 3000;

SELECT * FROM EMP WHERE sal >= 1100 AND sal <= 3000;

SELECT * FROM EMP WHERE sal BETWEEN 1100.00 AND 3000.00;
-- fetching all rows inclusive of both ends in given range.

SELECT * FROM EMP WHERE hire BETWEEN '1981-01-01' AND '1981-12-31';

SELECT * FROM EMP WHERE ename BETWEEN 'C' AND 'T';

SELECT * FROM EMP WHERE ename NOT BETWEEN 'C' AND 'T';

-- IN
SELECT * FROM EMP WHERE empno = 7566 AND empno = 7900 AND empno = 7902;

SELECT * FROM EMP WHERE empno = 7566 OR empno = 7900 OR empno = 7902;

SELECT * FROM EMP WHERE empno IN (7566, 7900, 7902);

SELECT * FROM EMP WHERE empno NOT IN (7566, 7900, 7902);

-- LIKE operator

SELECT * FROM EMP WHERE ename LIKE 'A%';

SELECT * FROM EMP WHERE ename LIKE '%S';

SELECT * FROM EMP WHERE ename LIKE '%LA%';

-- 

SELECT ename, deptno FROM EMP;

SELECT * FROM DEPT;

SELECT ename, deptno,
CASE
WHEN deptno=10 THEN 'ACCOUNTING'
WHEN deptno=20 THEN 'RESEARCH'
WHEN deptno=30 THEN 'SALES'
ELSE 'OPERATIONS'
END
AS dname
FROM EMP;

```

```C
#include <stdio.h>
int main()
{
	int arr[] = {11, 22, 33, 44, 55, 66};
	for(int i=0; i<6; i++)
	{
		if(arr[i] == 22 || arr[i] == 55 || arr[i] == 11)
		{
			printf("%d\n", arr[i]);
		}
	}
	return 0;
}
```

# UPDATE queries
* Used to modify one or more records.

```SQL
CREATE TABLE EMP2 AS SELECT * FROM EMP;

UPDATE EMP2 SET sal=1000.00 WHERE ename='SMITH';

UPDATE EMP2 SET sal=1500.00, comm=100.00 WHERE empno=7900;

UPDATE EMP2 SET sal=sal + sal * 0.10 WHERE deptno=30;

UPDATE EMP2 SET sal=sal + sal * 0.05;

UPDATE EMP2 SET sal=sal + sal * 0.05 WHERE deptno=30 AND job='SALESMAN' AND comm IS NULL;
```

# DELETE queries
* Delete one or more records/rows in a table.

```SQL
DELETE FROM EMP2 WHERE empno=7900;

DELETE FROM EMP2 WHERE job='MANAGER';

DELETE FROM EMP2; -- DML query (can rollback in transaction)

TRUNCATE EMP2; -- DDL query (cannot be rollback in transaction)

DROP TABLE EMP2; -- DDL query
```


