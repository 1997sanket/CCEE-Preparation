# RDBMS design
	- Data
		- Files
		- Simple DBMS
	- 1985 -- IBM
		- E. F. Codd
			- Relational model of data.
			- Mathematician
		- Relational model of data
			- Tables, Rows & Columns
			- Relations in table.
				- One-to-One
				- One-to-Many
				- Many-to-One
				- Many-to-Many
		- Codd's Rules
			- Rules to design RDBMS
			- Efficient storage & processing of huge data
		- IBM -- RDBMS -- DB2 RDBMS - Mainframe

### Codd's 12 Rules -- 0 to 12
* Codd's Rule 0 -- Foundation Rule
	- For any system that is claimed to be, a RDBMS, that system must be able to  manage databases entirely through its relational capabilities.

* Codd's Rule 1 to 12.

# NoSQL vs RDBMS
* 

# Mongo DB

## Introduction
* One record is one document (like row).
* Collection of records is a collection (like table).
* Example: Person's data
```JS
// JSON -- Java Script Object Notation
{
	"name": "Nilesh Ghule",
	"birth": ISODate("28-09-1983"),
	"age": 35,
	"gender": "Male",
	"address": {
		"area": "Katraj",
		"city": "Pune",
		"state": "Maharashtra",
		"pin": 411046
	},
	"hobbies": [ "Teaching", "Programming", "Cooking", "Playing", "Reading" ],
	"interestedInPolitics": false,
	"rating": 3.76
}
```
* JSON syntax:
	- The object data is -- { ... }
	- Each element is key-value pair -- separated by :
		- key are strings in double quotes.
		- value may or may not be double quotes.
	- possible values:
		- strings -- in double quotes e.g. "nilesh@sunbeaminfo.com"
		- ints, floats -- not in double quotes.
		- boolean -- true or false (not in double quotes).
		- special values -- ISODate(), ObjectID(), ...
		- arrays -- multiple values in [ ... ]
		- nested documents -- { ... }
* Mongo documents are inserted in JSON format.
* Internally they are converted into BSON format for efficient storage -- Binary JSON.
* Document support various data types. Internally each data type is represented by number.
	- number
	- string
	- date
	- objectid
	- boolean
	- array -- 4
	- document
	- null -- 10
* Each document have a unique id -- "_id" field.
* If given by user, user should ensure that "_id" is not repeated.
* If not given by user, "_id" is auto generated of type ObjectId.
	- ObjectId is of 12 bytes.
	- 3 (counter) | 2 (pid)  | 3 (machine) | 4 (time)
	
## Installation on Ubuntu
* terminal> sudo apt-get install mongodb-org
	- installs server & client
	- server: mongod
	- client: mongo shell
	
* terminal> netstat -tlnp
	- Port 21017 is used by mongod.

* terminal> sudo systemctl status mongodb

* terminal> sudo systemctl stop mongodb

* terminal> sudo systemctl start mongodb

* Mongo Shell:
	- terminal> mongo
	- This is JS shell i.e. JS statements are executed on this shell.
	
## CRUD operations
```JS
show databases;

use dacdb;
	// db is auto created when 1st doc is stored.

db.contacts.insert({
	"name": "Nilesh Ghule",
	"email": "nilesh@sunbeaminfo.com",
	"mobile": "9527331338"
});

db.contacts.insert({
	"name": "Nitin Kudale",
	"email": "nitin@sunbeaminfo.com",
	"mobile": "9881208115",
	"office": "020-24260308"
});

db.contacts.insert({
	"name": "Sandeep Kulange",
	"email": "sandeepkulange@sunbeaminfo.com"
});

db.contacts.insert({
	"name": "Prashant Lad",
	"email": null,
	"mobile": "9881208114"
});

show collections;
	// collection is auto created when 1st record is inserted.

db.contact.find();
	// returns a cursor object.
```

## Retrieving records

* Important methods of cursor object.
	- Cursor object is returned by find() method.
	- pretty() -- beautify/format the output.
	- limit() -- fetch n records.
	- skip() -- skip n records.
	- sort() -- sort records by given key.

```JS
db.contacts.find().pretty();

db.contacts.find().limit(3);

db.contacts.find().skip(2);

db.contacts.find().skip(1).limit(2);

db.contacts.find().sort({"name": 1});

db.contacts.find().sort({"name": -1});

db.contacts.find().sort({"name": -1, "email": 1});
```

* Projection
- Selecting particular fields from each record.

```JS
db.contacts.find({}, {
	"name": 1,
	"email": 1
});

db.contacts.find({}, {
	"email": 0,
	"mobile": 0
});

db.contacts.find({}, {
	"email": 1,
	"mobile": 0
}); // error
```

* Insert emp & dept data

```JS
db.dept.remove({});
db.emp.remove({});

db.dept.insert({_id:10,dname:"ACCOUNTING",loc:"NEW YORK"});
db.dept.insert({_id:20,dname:"RESEARCH",loc:"DALLAS"});
db.dept.insert({_id:30,dname:"SALES",loc:"CHICAGO"});
db.dept.insert({_id:40,dname:"OPERATIONS",loc:"BOSTON"});

db.emp.insert({_id:7369,ename:"SMITH",job:"CLERK",mgr:7902,sal:800.00,deptno:20});
db.emp.insert({_id:7499,ename:"ALLEN",job:"SALESMAN",mgr:7698,sal:1600.00,comm:300.00,deptno:30});
db.emp.insert({_id:7521,ename:"WARD",job:"SALESMAN",mgr:7698,sal:1250.00,comm:500.00,deptno:30});
db.emp.insert({_id:7566,ename:"JONES",job:"MANAGER",mgr:7839,sal:2975.00,deptno:20});
db.emp.insert({_id:7654,ename:"MARTIN",job:"SALESMAN",mgr:7698,sal:1250.00,comm:1400.00,deptno:30});
db.emp.insert({_id:7698,ename:"BLAKE",job:"MANAGER",mgr:7839,sal:2850.00,deptno:30});
db.emp.insert({_id:7782,ename:"CLARK",job:"MANAGER",mgr:7839,sal:2450.00,deptno:10});
db.emp.insert({_id:7788,ename:"SCOTT",job:"ANALYST",mgr:7566,sal:3000.00,deptno:20});
db.emp.insert({_id:7839,ename:"KING",job:"PRESIDENT",sal:5000.00,deptno:10});
db.emp.insert({_id:7844,ename:"TURNER",job:"SALESMAN",mgr:7698,sal:1500.00,comm:0.00,deptno:30});
db.emp.insert({_id:7876,ename:"ADAMS",job:"CLERK",mgr:7788,sal:1100.00,deptno:20});
db.emp.insert({_id:7900,ename:"JAMES",job:"CLERK",mgr:7698,sal:950.00,deptno:30});
db.emp.insert({_id:7902,ename:"FORD",job:"ANALYST",mgr:7566,sal:3000.00,deptno:20});
db.emp.insert({_id:7934,ename:"MILLER",job:"CLERK",mgr:7782,sal:1300.00,deptno:10});
```

* Criteria

```JS
// db.emp.find({criteria}, {projection})

db.emp.find({
	"ename": "KING"
});

db.emp.find({
	"deptno": 20
});

db.emp.find({
	"deptno": 20,
	"job": "ANALYST"
});

// $eq, $ne, $gt, $lt, $gte, $lte
db.emp.find({
	"sal": { $lt : 2000 }
});

//Q. find emp who are in dept 20 or are clerk
//SELECT * FROM EMP WHERE deptno=20 OR job='CLERK';
db.emp.find({
	$or : [
		{ "deptno" : 20 },
		{ "job" : "CLERK" }
	]
});

//Q. find emp who clerk or analyst or salesman.
//SELECT * FROM EMP WHERE job='CLERK' OR job='ANALYST' OR job='SALESMAN';
db.emp.find({
	$or : [
		{"job": "CLERK"},
		{"job": "ANALYST"},
		{"job": "SALESMAN"}
	]
});

//Q. find emp who clerk or analyst or salesman.
//SELECT * FROM EMP WHERE job IN ('CLERK', 'ANALYST', 'SALESMAN');
db.emp.find({
	"job": {
		$in: ["CLERK", "ANALYST", "SALESMAN"]
	}
});
``` 

* CRUD operations
```JS
db.dept.find();

//Q. Make loc='Delhi' for deptno=40.
//db.dept.update({criteria}, {changes});
db.dept.update({
	"_id": 40
}, {
	"loc": "DELHI"
});

db.emp.update({
	"ename": "KING"
}, {
	"sal": 4500.00
});

// above two queries will overwrite whole record.
// remaining fields will be lost.

db.dept.update({
	"_id": 30
}, {
	$set: { "loc": "MUMBAI" }
});

db.dept.update({
	"_id": 50
}, {
	$set: { "loc": "PUNE" }
}, 
true);
// If record with given criteria is available, update it.
// Otherwise create new record with given criteria & then update it
// 3rd param of update() is upsert. Default is false.

//db.emp.remove({criteria});
db.dept.remove({
	"_id": 50
});

db.dept.remove({});
```

* Question
```JS
db.emp.find({
	$or: [
		{ 
			$and : [
				{ "deptno" : 30 },
				{ "job" : "SALESMAN" }
			]
		},
		{ "sal" : { $gt : 2500 } }
	]
});
```

