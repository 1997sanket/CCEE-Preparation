# Sub-queries

```SQL
SET SESSION optimizer_switch='materialization=off';

EXPLAIN FORMAT=json SELECT deptno, dname FROM DEPT
WHERE deptno = ANY(SELECT DISTINCT(deptno) FROM EMP);
-- 6.90 (materialization=off)
-- 5.30 (materialization=on)

EXPLAIN FORMAT=json SELECT deptno, dname FROM DEPT
WHERE deptno IN (SELECT DISTINCT(deptno) FROM EMP);
-- 6.90 (materialization=off)
-- 5.30 (materialization=on)

EXPLAIN FORMAT=json SELECT d.deptno, d.dname FROM DEPT d
WHERE d.deptno = ANY(SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);
-- 6.90

EXPLAIN FORMAT=json SELECT d.deptno, d.dname FROM DEPT d
WHERE d.deptno IN (SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);
-- 6.90

EXPLAIN FORMAT=json SELECT d.deptno, d.dname FROM DEPT d
WHERE (SELECT COUNT(empno) FROM EMP e WHERE e.deptno = d.deptno) > 0;
-- 0.65

EXPLAIN FORMAT=json SELECT d.deptno, d.dname FROM DEPT d
WHERE EXISTS (SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);
-- 0.65

```

* Sub-queries are also allowed in UPDATE & DELETE statements (in some RDBMSes).
```SQL
DELETE FROM EMP WHERE sal < (SELECT AVG(sal) FROM EMP);
-- Not allowed in MySQL

DELETE FROM DEPT
WHERE deptno NOT IN (SELECT deptno FROM EMP);
-- allowed in MySQL

```

# Checking query performance
* Query performance can be checked using **EXPLAIN** keyword.
* **EXPLAIN FORMAT=TRADITIONAL** displays minimal info.
* **EXPLAIN FORMAT=JSON** displays detailed query execution plan.
	- **query_cost** is most important field representing performance.
* In MySQL, **optimizer_switch** is a global variable that defines optimization settings for the quries.

```SQL
SELECT @@optimizer_switch;

```


# Indexes

* Order of Index:
	* ASC
	* DESC

* Types of Index:
	* Simple Index
	* Unique Index
	* Composite Index

```SQL
EXPLAIN FORMAT=JSON SELECT deptno, SUM(sal) FROM EMP
GROUP BY deptno;

EXPLAIN FORMAT=JSON SELECT * FROM EMP ORDER BY deptno;

CREATE INDEX idx_emp_deptno ON EMP(deptno);

EXPLAIN FORMAT=JSON SELECT deptno, SUM(sal) FROM EMP
GROUP BY deptno;

EXPLAIN FORMAT=JSON SELECT * FROM EMP ORDER BY deptno;

DROP INDEX idx_emp_deptno ON EMP;

CREATE INDEX idx_emp_sal ON EMP(sal DESC);

CREATE UNIQUE INDEX idx_emp_empno ON EMP(empno);

CREATE INDEX idx_emp_deptno_job ON EMP(deptno, job);

CREATE INDEX idx_emp_job_deptno ON EMP(job, deptno);

SHOW INDEXES FROM EMP;

```

* Most of db doesn't support indexing on text/blob, because they are external to the record/row.
* MySQL support indexing on text/blob, but num of chars/bytes should be specified while creating index on text/blob. Only those many chars/bytes will compared while entering index.
* Indexing should be preferred on CHAR or INT columns.

# Join
* Getting combined results from two tables is done using "joins".
* Joins internally use nested loops.

```SQL
CREATE TABLE DEPT (deptno INT, dname VARCHAR(20));
INSERT INTO DEPT VALUES (10, 'DEV');
INSERT INTO DEPT VALUES (20, 'QA');
INSERT INTO DEPT VALUES (30, 'OPS');
INSERT INTO DEPT VALUES (40, 'ACC');

CREATE TABLE EMP (empno INT, ename VARCHAR(20), deptno INT);
INSERT INTO EMP VALUES (1, 'Amit', 10);
INSERT INTO EMP VALUES (2, 'Rahul', 10);
INSERT INTO EMP VALUES (3, 'Nilesh', 20);
INSERT INTO EMP VALUES (4, 'Nitin', 50);
INSERT INTO EMP VALUES (5, 'Sarang', 50);
```

------------------
| deptno | dname |
|--------|-------|
|     10 | DEV   |
|     20 | QA    |
|     30 | OPS   |
|     40 | ACC   |
------------------

---------------------------
| empno | ename  | deptno |
|-------|--------|--------|
|     1 | Amit   |     10 |
|     2 | Rahul  |     10 |
|     3 | Nilesh |     20 |
|     4 | Nitin  |     50 |
|     5 | Sarang |     50 |
---------------------------

## Cross Join
* Gives you all possible combinations.
* Also called as "Cartesian Product".
* Num of output records = Num of records in Table1 * Num of records in Table2
* Join without any join condition.

```
foreach e in emps
{
	foreach d in depts
	{
		print e.empno, e.ename, d.dname
	}
}
```

```SQL
SELECT e.empno, e.ename, d.dname
FROM EMP e CROSS JOIN DEPT d;
```

## Inner Join
* Rows matching from both tables will be displayed.
* Join condition must be specified.
* Equi-Join -- Checking two columns are equal.
* Non-Equi-Join -- Comparing two columns.

```
foreach e in emps
{
	foreach d in depts
	{
		if(e.deptno == d.deptno)
			print e.empno, e.ename, d.dname
	}
}
```

```SQL
SELECT e.empno, e.ename, d.dname
FROM EMP e INNER JOIN DEPT d ON e.deptno = d.deptno;
```

## Left Outer Join
* Rows matching from both tables will be displayed + Extra rows from Left table will also be displayed.
* OUTER keyword is optional.
	- LEFT OUTER JOIN
	- LEFT JOIN

```
foreach e in emps
{
	found = 0
	foreach d in depts
	{
		if(e.deptno == d.deptno)
		{
			print e.empno, e.ename, d.dname
			found = 1
		}
	}
	if(found == 0)
		print e.empno, e.ename, NULL
}
```

```SQL
SELECT e.empno, e.ename, d.dname
FROM EMP e LEFT OUTER JOIN DEPT d ON e.deptno = d.deptno;
```

## Right Outer Join
* Rows matching from both tables will be displayed + Extra rows from Right table will also be displayed.
* OUTER keyword is optional.
	- RIGHT OUTER JOIN
	- RIGHT JOIN

```
foreach d in depts
{
	found = 0
	foreach e in emps
	{
		if(e.deptno == d.deptno)
		{
			print e.empno, e.ename, d.dname
			found = 1
		}
	}
	if(found == 0)
		print NULL, NULL, d.dname
}
```

```SQL
SELECT e.empno, e.ename, d.dname
FROM EMP e RIGHT OUTER JOIN DEPT d ON e.deptno = d.deptno;

SELECT e.empno, e.ename, d.dname
FROM DEPT d LEFT OUTER JOIN EMP e ON e.deptno = d.deptno;
```

## Full Outer Join 
* Rows matching from both tables will be displayed + Extra rows from Right table will also be displayed + Extra rows from Left table will also be displayed.
* Full outer join is UNION of Left Outer Join & Right Outer Join.
* In MySQL, Full outer join is not supported.

## Set Operators
* UNION operator
```SQL
(SELECT e.empno, e.ename, d.dname
FROM EMP e LEFT OUTER JOIN DEPT d ON e.deptno = d.deptno)
UNION
(SELECT e.empno, e.ename, d.dname
FROM EMP e RIGHT OUTER JOIN DEPT d ON e.deptno = d.deptno);
```

* UNION ALL operator
```SQL
(SELECT e.empno, e.ename, d.dname
FROM EMP e LEFT OUTER JOIN DEPT d ON e.deptno = d.deptno)
UNION ALL
(SELECT e.empno, e.ename, d.dname
FROM EMP e RIGHT OUTER JOIN DEPT d ON e.deptno = d.deptno);
```

## Self Join
* When Left & Right both tables are same, then it is self join.
* Left & Right tables are identified by two different aliases.
* You may perform INNER or OUTER join.

e -- empno, ename, mgr, job, hire, sal, comm, deptno
m -- empno, ename, mgr, job, hire, sal, comm, deptno

```
foreach e in emps
{
	foreach m in emps
	{
		if(e.mgr == m.empno)
			print e.ename, m.ename
	}
}
```

```SQL
SELECT e.ename, m.ename
FROM EMP e INNER JOIN EMP m ON e.mgr = m.empno;

SELECT e.ename, m.ename
FROM EMP e LEFT OUTER JOIN EMP m ON e.mgr = m.empno;
```

```SQL
-- Q. Print dname and num of employees in each dept.
SELECT d.dname, COUNT(e.empno)
FROM DEPT d LEFT JOIN EMP e ON d.deptno = e.deptno
GROUP BY d.dname;

-- Q. Print name of dept which spend max on emp salaries.
SELECT d.dname, SUM(e.sal) total
FROM DEPT d LEFT JOIN EMP e ON d.deptno = e.deptno
GROUP BY d.dname
ORDER BY total DESC
LIMIT 1;

-- Q. Print ename, mgrname & deptname of each emp.
SELECT e.ename, m.ename, d.dname
FROM EMP e
INNER JOIN EMP m ON e.mgr = m.empno
INNER JOIN DEPT d ON e.deptno = d.deptno;

SELECT e.ename, m.ename, d.dname
FROM EMP e
LEFT JOIN EMP m ON e.mgr = m.empno
INNER JOIN DEPT d ON e.deptno = d.deptno;


-- Q. Print manager with max num of subbordinates along with his dept name.

```

```SQL
-- Q. Print ename & dname.
-- ANSI std SQL
SELECT e.ename, d.dname
FROM EMP e INNER JOIN DEPT d ON e.deptno = d.deptno;

-- non-std SQL
SELECT e.ename, d.dname
FROM EMP e, DEPT d
WHERE e.deptno = d.deptno;
```

## Normalization
* If whole data is in same table, data will reduandent/duplicate.
* It needs more space and unefficient to process.
* It also suffer from INSERT anomaly, UPDATE anomaly, DELETE anomaly. It also slowdown all DML operations.
* So data must organized into multiple tables for efficient storage & processing. This process of deciding database structure is called as "Normalization".
* After Normalization we come up with multiple tables related to each other.
* Possible relations among the tables
	- One to One relation
	- One to Many relation
	- Many to One relation
	- Many to Many relation

