# Transactions
* Set of DML queries as a single unit.
* ACID properties.
* In MySQL, by default autocommit is 1. It means, whenever DML query is executed, it is automatically commited. In other words, one DML query is one transaction, which is always committed.

```SQL
SELECT @@autocommit;

SET autocommit = 0;
```
* When autocommit is 0, DML queries will not be committed immediately. They will be committed when COMMIT is done.
* Same effect is achieved using `START TRANSACTION` command.

## Isolation
* When multiple users are executing multiple queries (transactions), they should not affect each other. These should be executed in isolated manner.
* When one user is inserting records, until he commits, those records should not be visible to other users.
* When one user is updating records, until he commits, those changes in records should not be visible to other users.
* When one user is deleting records, until he commits, those records should be visible to other users.
* All queries from all clients are maintained in a request queue on db server. They are processes one after another.
* For each user's each transaction a temporary table is created on server side. The changes done by user in that tx, are maintained in that temp table. When that user select records, the merge of main table & temp table is presented to the user (in that tx).
* When user rollback the current tx, the temp table is discarded. If user commits the current tx, then changes in temp table are applied on main table & made permanent on server disk.

## Row Locking
### Optimistic Row Locking
* Db decides which records to be locked when & when to release the lock in most optimistic manner.
* When user update/delete a record within a tx, changes will be marked in temp table. At the same time, those records will be locked in main table; so that these records can be selected by other users, but not updated/deleted by other user. If other user try to update/delete the same record (before completion of tx of first user), it will be blocked until tx of first user is committed or rollbacked or a timeout period is over.
* In MySQL, to ensure row level locking table must have index/primary key. If PK is not there, then MySQL follow table level locking i.e. another user cannot update/delete any row from that table.

#### example 1
```SQL
-- USER 1
ALTER TABLE DEPT ADD PRIMARY KEY (deptno); -- 1

START TRANSACTION; -- 2

SELECT * FROM DEPT; -- 3

UPDATE DEPT SET loc='Xyz' WHERE deptno=50; -- 5

COMMIT; -- 8
```

```SQL
-- USER 2
SELECT * FROM DEPT; -- 4

SELECT * FROM DEPT; -- 6

UPDATE DEPT SET loc='Pqr' WHERE deptno=50; -- 7 (blocked)

SELECT * FROM DEPT; -- 8 (loc will be 'Pqr')
```

#### example 2
```SQL
-- USER 1
START TRANSACTION; -- 1

SELECT * FROM DEPT; -- 2

DELETE FROM DEPT WHERE deptno=50; -- 4

COMMIT; -- 7
```

```SQL
-- USER 2
SELECT * FROM DEPT; -- 3

SELECT * FROM DEPT; -- 5

UPDATE DEPT SET loc='Pqr' WHERE deptno=50; -- 6 (blocked)

SELECT * FROM DEPT; -- 8 (no rows affected)
```

#### example 3
```SQL
-- USER 1
START TRANSACTION; -- 1

SELECT * FROM DEPT; -- 2

DELETE FROM DEPT WHERE deptno=50; -- 4

ROLLBACK; -- 7
```

```SQL
-- USER 2
SELECT * FROM DEPT; -- 3

SELECT * FROM DEPT; -- 5

UPDATE DEPT SET loc='Pqr' WHERE deptno=50; -- 6 (blocked)

SELECT * FROM DEPT; -- 8 (loc will be 'Pqr')
```

#### example 4
```SQL
-- USER 1
ALTER TABLE DEPT ADD PRIMARY KEY (deptno); -- 1

START TRANSACTION; -- 2

SELECT * FROM DEPT; -- 3

UPDATE DEPT SET loc='Xyz' WHERE deptno=50; -- 5

COMMIT; -- 8
```

```SQL
-- USER 2
SELECT * FROM DEPT; -- 4

SELECT * FROM DEPT; -- 6

UPDATE DEPT SET loc='Pqr' WHERE deptno=60; -- 7 (not blocking)

SELECT * FROM DEPT; -- 8 
```

### Pessimistic Row Locking
* User can decide which rows are to be locked for update/delete operation further. After update/delete user will commit/rollback tx and then rows lock will be released.
* In this case rows might be locked for longer duration than optimistic locking. But this is helpful in certain applns like reservation systems, ...

#### example 1

```SQL
-- USER 1
START TRANSACTION; -- 1

SELECT * FROM DEPT WHERE deptno=50 FOR UPDATE; -- 2

UPDATE DEPT SET loc='Pqr' WHERE deptno=60; -- 5

COMMIT; -- 6

```

```SQL
-- USER 2

SELECT * FROM DEPT; -- 3

SELECT * FROM DEPT WHERE deptno=50 FOR UPDATE; -- 4 (blocked)

SELECT * FROM DEPT; -- 7

UPDATE DEPT SET loc='Xyz' WHERE deptno=60; -- 8

SELECT * FROM DEPT; -- 9

```

# MySQL Programming Langauge -- PSL.
* Programming languages differ from RDBMS to RDBMS. All popular db even though support similar programming concepts like functions, procedures, triggers, exception handling, cursors, etc; they have some differences in their syntax.
* MySQL PL is used to write MySQL programs which will be executed on MySQL RDBMS server. Different types of MySQL programs are functions, procedures, triggers, ...
* MySQL programs can be accessed from MySQL client or any other programming language e.g. Java - JDBC.
* These programs always execute in server RAM and results are produced.
* Programs are faster than simple SQL statements. Because they are already compiled and stored in server.
* Advantages:
	- Reusability -- used/called multiple times.
	- Modularity -- maintainable.
	- Extended Functionalities -- Additional functionalities than provided by RDBMS.
	- Faster execution -- Pre-compiled.
	- Encapsulation -- Hide program logic from client.
* MySQL PL is Procedural language.
	- Block based language -- Code blocks can be nested.
	- Programming constructs -- if, if-else, case, while, loop, ...
	- Error handling is supported.
	- Support many SQL statements i.e. SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, COMMIT, ROLLBACK.
	- Using TCL & DQL is not recommended.
* Typically output of programs are not displayed on console. Instead outputs are inserted in a separate "results" table.
* In MySQL, SELECT statements in MySQL programs work well (but not very common to use).

# MySQL Variables
* Variables are classified as
	- User defined variables
	- System variables
	
## User defined variables
* Used for holding values temporarily.
* Available in current session only.
* Initialized using SET command.
	- Can use = or := operator.
* Can be modified in any command.
	- Must use := operator.
	- = is considered as comparision in SELECT statement.
* Can be displayed using SELECT.
* @ represent user-defined variables.
* They can be used in quries.

```SQL
SET @course='dac';

SELECT @course;

SELECT UPPER(@course);


SET @avgsal = (SELECT AVG(sal) FROM EMP);

SELECT * FROM EMP WHERE sal > @avgsal;


SET @srno = 0;

SELECT @srno:=@srno+1, ename, sal FROM EMP;
```

## System variables
* Values defined by MySQL for db settings/config.
* Variables can be set in GLOBAL or SESSION scope.
* To change variables in GLOBAL scope user must have SUPER privilege.
* Can be modified using SET command.
* Can be displayed using SELECT or SHOW VARIABLES.
* @@ represent system variables.

```SQL
SHOW VARIABLES;

SHOW VARIABLES LIKE '%name%';

SHOW VARIABLES LIKE 'hostname';

SELECT @@hostname, @@version, @@foreign_key_checks;

SET @@foreign_key_checks = 0;

SET GLOBAL @@foreign_key_checks = 0;
-- need SUPER privilege

SELECT @@foreign_key_checks;
```

# MySQL Stored Procedures
* MySQL SP is a kind of MySQL program.
* It is compiled & stored on server side as a db object.
* SP code is stored in MySQL system table i.e. information_schema.routines.
* Procedure is set of SQL statements (routine), that doesn't result any value.
* SP can have one or more parameters.

```SQL
SHOW PROCEDURE STATUS;

SHOW PROCEDURE STATUS LIKE 'SP_%';

DROP PROCEDURE stored_proc_name;
```

* By default, when SQL statement end with ;, MySQL client send it to server & compile it.
* However, SP is set of SQL statements (i.e. will have multiple ;). Hence SP should be submitted only after completing whole procedure.
* This can be done by setting different delimiter e.g. $$ using `DELIMITER $$` statement.
* After submitting SP (ended with $$), we can reset delimiter to ; using `DELIMITER ;` statement.

```SQL
DELIMITER $$

CREATE PROCEDURE SP_PRINT_TIME()
BEGIN
	SELECT NOW() FROM DUAL;
END;

DELIMITER ;

CALL SP_PRINT_TIME();
```

* SQL scripts (.sql file) is simple way of writing SP.

```SQL
-- Open editor (like gedit, scite, kate, ...)
-- Implement SP along with DELIMITER statements.

SOURCE /path/to/sp.sql;

CALL sp_name();
```











# MySQL Stored Functions
* Function is set of SQL statements (routine), that does result some value.















