# Stored Procedure
* Insert result into another table
* Return result using select statement
* Variables & arithmetic
* Get select query result into the variable
* Using SQL functions
* if, if-else, elseif, case-when
* while, repeat, loop, leave, iterate
* Parameters: IN, OUT, INOUT

```C
#include <stdio.h>
void sum(int a, int b, int *p) // called fn
{
	// a & b -- input params
	// p -- output params
	*p = a + b;
}
void sqr(int *n) // called fn
{
	// n -- input-output param
	*n = (*n) * (*n);
}
int main() // calling fn
{
	int x=10, y=20, z;
	sum(x, y, &z);
	printf("result = %d\n", z); // 30
	sqr(&z);
	printf("result = %d\n", z); // 900
	return 0;
}
```

### Stored Procedure Param Types
* IN:
	- Used to give input to the function.
	- By default each param is input param. Can also use IN keyword.
	- These params must be initialized by calling program.
	- You can pass const values or some session variables.
	- Always passed by value i.e. any change in var within proc will not reflect in calling program.

* OUT:
	- Used to take output from the function.
	- It can be declared using OUT keyword.
	- These params must be initialized by called proc.
	- Calling program can pass session variables.
	- Like pass by address. Changes done in var within proc will be available in calling program.

* INOUT
	- Used to give input to the function as well as to take output from the function.
	- It can be declared using INOUT keyword.
	- These params must be initialized by calling program and will be modified by called proc.
	- Calling program can pass session variables.
	- Like pass by address. Changes done in var within proc will be available in calling program.

# Stored Functions
* Stored Functions are also MySQL programs/routines.
* Stored functions (unlike Stored procs) can return values.
* In MySQL, SF cannot have OUT or INOUT params. By default all its params are IN params.
* SF are executed from SQL statements (typically SELECT).
* Also called as UDF -- User Defined Functions.
* SF can have one or more RETURN statements, but only one RETURN statement is executed. Once RETURN statement is executed, control returns back to the calling program.
* SF are called using SELECT statement like Single row functions. When used in context of a table, they will be executed for each row. Hence SF must be light-weight; otherwise overall db performance will go down.
* In MySQL 8.0, log_bin_trust_function_creators variable should be set to 1 by admin/root login to create function.
* In MySQL, there are two types of fns i.e. deterministic & non-deterministic.
* Programmer should mark a fn as deterministic, if its output/result depends only on its input params. Internally, MySQL cache results of fn corresponding to its input args. If fn is called again with same params, result will be reused. In this case, fn call may be skipped to improve the performance.
* Programmer should mark a fn as non-deterministic, if its output depends on date-time, state of table and other factors (other than only args). These fn results will not be cached by MySQL.

# Error/Exception Handling
* During execution of queries/procedure/functions there can be runtime errors. Each error in MySQL have some error code, sql state associated and error message associated with that.
* It is expected that errors in MySQL programs (SP/SF/...) must be handled by the programmer.
* To handle the error, programmer should specify error handler.

```
DECLARE action HANDLER FOR condition handler_implementation;
```

* There are two possible actions i.e. EXIT or CONTINUE.
	- EXIT: When error occured that program will exit after handling the error.
	- CONTINUE: When error occured that program will continue further execution after handling the error.

* There are three possible ways of giving condition:
	- ERROR CODE - e.g. 1146 Table Not Found, 1062 Duplicate, 1142 Access denied.
	- SQL STATE - e.g. 23000 Duplicate values, 42000 Access denied, NOTFOUND No more data available for SELECT INTO or Cursor.
	- ERROR alias - e.g.
		- DECLARE duplicate CONDITION FOR 1062; 

* Handler can be implemented in two ways:
	- Single liner: e.g. SELECT 'error message' output;
	- PL Block:
```	
		BEGIN
			-- ...
			SELECT 'error message' output;	
		END;
```

# Cursors
* Cursor is used to access the values/rows one at a time (one by one).
* Cursor is a special variable used in MySQL programs to process records one by one.
* In general, it is used for reading, updating or deleting records.
* In MySQL, cursors are read-only i.e. cannot be used for update or delete.
* In MySQL, cursors are forward-only.
* In MySQL, cursors are sensitive. The changes made in table after opening the cursor (by some other client), will be accessible using current cursor. No copy of the current data is created.
* Before fetching rows, open the cursor. Use that cursor for accessing rows data one by one until no more records left. After completing processing close the cursor.
* When cursor reach after last record, NOTFOUND error is generated.
* If cursor is not closed, it will be automatically closed at the end of PL block. This is very bad practice.
* The SELECT query of cursor can be simple query or it may contain GROUP BY, ORDER BY, HAVING, WHERE, SUBQUERIES or JOINS.
* Cursor can be used to modify records within a table using pessimistic locking.

```
Q. Insert "empno" & "ename - dname" into RESULTS table using CURSOR.
Hint:
	DECLARE v_cur CURSOR FOR SELECT e.empno, e.ename, d.dname FROM EMP e INNER JOIN DEPT d ON e.deptno = d.deptno;
```

# Triggers
* Trigger is also a MySQL program -- compiled & stored on server.
* Triggers cannot be invoked by the programmer explicitly. Their execution is triggered on some event.
* Triggers are executed in context of DML operations. They can be executed before or after DML operations.
* Types of Triggers:
	- BEFORE INSERT
	- AFTER INSERT
	- BEFORE UPDATE
	- AFTER UPDATE
	- BEFORE DELETE
	- AFTER DELETE
* Trigger is also PL routine and hence follow same syntaxes as of procedures & functions.
* Trigger parameters pre-defined. They depend on type of trigger.
* Trigger should not contain DDL, DQL & TCL statements.
* Triggers are executed in current transaction (in which DML operation is in progress).

```SQL
SELECT * FROM information_schema.routines;
```




















