# Select clauses
1. WHERE -- to give some condition.
	- This condition will be **applied on each row/record**.
	- Those records will be selected for which condition is true.
2. GROUP BY -- to group rows by some column & perform aggregate ops.
	- aggregate fns: SUM(), MIN(), MAX(), AVG(), COUNT().
	- SELECT column must be in GROUP BY.
3. HAVING -- to give some condition along with GROUP BY.
	- This condition will be **applied on aggregate value**.
4. ORDER BY -- to arrange in asc/desc order.
	- any col or computed col or aggregate value.
5. LIMIT -- to select first n rows after m rows.
	- Can skip m rows -- LIMIT m,n
	- Can select n rows -- LIMIT n
	
```SQL

--Q. For which job avg sal is below 1500 out of president/salesman/analyst.

SELECT job, sal FROM EMP
WHERE job IN ('PRESIDENT', 'SALESMAN', 'ANALYST');

SELECT job, AVG(sal) FROM EMP
WHERE job IN ('PRESIDENT', 'SALESMAN', 'ANALYST')
GROUP BY job;

SELECT job, AVG(sal) FROM EMP
WHERE job IN ('PRESIDENT', 'SALESMAN', 'ANALYST')
GROUP BY job
HAVING AVG(sal) < 1500;

SELECT job, AVG(sal) FROM EMP
WHERE (job = 'PRESIDENT' OR job = 'SALESMAN' OR job = 'ANALYST')
GROUP BY job
HAVING AVG(sal) < 1500;

--Q. For which job avg sal is minimum out of president/salesman/analyst.

SELECT job, AVG(sal) FROM EMP
WHERE job IN ('PRESIDENT', 'SALESMAN', 'ANALYST')
GROUP BY job
ORDER BY AVG(sal) ASC
LIMIT 1;

SELECT MIN(avgsal) FROM
(SELECT job, AVG(sal) avgsal FROM EMP
WHERE job IN ('PRESIDENT', 'SALESMAN', 'ANALYST')
GROUP BY job) AS avgsal_byjob;

--Q. For which job avg sal is second minimum out of president/salesman/analyst.
SELECT job, AVG(sal) FROM EMP
WHERE job IN ('PRESIDENT', 'SALESMAN', 'ANALYST')
GROUP BY job
ORDER BY AVG(sal) ASC
LIMIT 1, 1;

-- Q. Print 3rd lowest salaried employee.
SELECT empno, ename, sal FROM EMP
ORDER BY sal ASC
LIMIT 2, 1;
```

# Sub-Queries
```SQL
-- Print employees with second highest salary.

SELECT * FROM EMP
ORDER BY sal DESC
LIMIT 1,1;

SELECT * FROM EMP
WHERE sal = (SELECT DISTINCT sal FROM EMP ORDER BY sal DESC LIMIT 1,1);

-- Print all employees of a dept 'ACCOUNTING'.

SELECT * FROM DEPT;

SELECT * FROM EMP WHERE deptno = 10;

SELECT * FROM EMP
WHERE deptno = (SELECT deptno FROM DEPT WHERE dname='ACCOUNTING');

-- Print all depts having some employees

SELECT * FROM DEPT
WHERE deptno IN (SELECT DISTINCT deptno FROM EMP);

SELECT * FROM DEPT d
WHERE deptno IN (SELECT e.deptno FROM EMP e);

SELECT * FROM DEPT d
WHERE deptno IN (SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);

SELECT * FROM DEPT d
WHERE EXISTS (SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);

-- Print all emps whose sal is greater than sals of all emps in deptno 20;
SELECT * FROM EMP
WHERE sal > ALL(SELECT sal FROM EMP WHERE deptno=20);

-- Print all emps whose sal is greater than sal of any emp in deptno 20;
SELECT * FROM EMP
WHERE sal > ANY(SELECT sal FROM EMP WHERE deptno=20);

-- Print all emps from other depts whose sal is greater than sal of any emp in deptno 20;

SELECT * FROM EMP
WHERE deptno != 20 AND sal > ANY(SELECT sal FROM EMP WHERE deptno=20);

```

# Joins
* Inner Join:
	- Getting intersection of two tables
	- Two tables are matching with some column.

* Outer Join
	- Getting intersection of two tables + Extra rows from one of the table (Left or Right).
	- Two tables are matching with some column.

```SQL
SELECT * FROM departments;

SELECT * FROM employees WHERE employee_id = 0;

SELECT d.department_name, e.first_name
FROM departments d
INNER JOIN employees e ON d.manager_id = e.employee_id;

SELECT d.department_name, e.first_name
FROM departments d
LEFT JOIN employees e ON d.manager_id = e.employee_id;

SELECT * FROM employees;

SELECT e.first_name, m.first_name
FROM employees e
INNER JOIN employees m ON e.manager_id = m.employee_id;

-- wrong query
SELECT d.department_name, e.first_name
FROM departments d
LEFT JOIN employees e ON d.manager_id = e.manager_id;

```

```SQL
-- jobs.job_title
-- departments.department_name
-- employees.last_name
-- job_history.start_date

SELECT * FROM job_history h
WHERE YEAR(h.start_date) BETWEEN 1989 AND 1994;

SELECT h.start_date, j.job_title, d.department_name, e.last_name
FROM job_history h
INNER JOIN jobs j ON h.job_id = j.job_id
INNER JOIN departments d ON h.department_id = d.department_id
INNER JOIN employees e ON h.employee_id = e.employee_id
WHERE YEAR(h.start_date) BETWEEN 1989 AND 1994;

```

# Surrogate Key

```SQL

CREATE TABLE EMP(
empno INT AUTO_INCREMENT,
ename VARCHAR(20),
sal DECIMAL(8,2),
job VARCHAR(20),
PRIMARY KEY(empno)
);

INSERT INTO EMP(ename,sal,job) VALUES('Sarang', 20000, 'CM');
INSERT INTO EMP(ename,sal,job) VALUES('Nitin', 18000, 'MD');
INSERT INTO EMP(ename,sal,job) VALUES('Nilesh', 16000, 'TD');
```










# Question

```SQL
-- Print first names of all employees whose last name contains 'B' after 3rd letter.

SELECT last_name, SUBSTRING(last_name,4), INSTR(SUBSTRING(last_name, 4), 'b') FROM employees;

SELECT first_name, last_name FROM employees
WHERE INSTR(SUBSTRING(last_name, 4), 'b') > 0;

SELECT first_name, last_name FROM employees
WHERE INSTR(SUBSTRING(last_name, 4), 'b') = 1;

```















