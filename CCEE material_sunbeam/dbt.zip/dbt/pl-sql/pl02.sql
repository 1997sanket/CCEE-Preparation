/*DELIMITER $$

CREATE PROCEDURE SP_ARITHMETIC()
BEGIN
	DECLARE i INT; -- declaration
	DECLARE j INT;
	DECLARE c VARCHAR(40) DEFAULT 'DAC'; -- declaration + initialization
	
	SET i = 10; -- assignment
	SET j = i + 2;
	
	INSERT INTO RESULTS(first, second) VALUES(i, c);
	INSERT INTO RESULTS(first, second) VALUES(j, c);
END;
$$

DELIMITER ;

*/

DELIMITER $$

create procedure new_2()
begin

	declare i int;
	declare j int;
	declare c varchar(40) default 'DAC';

	set i= 10;
	set j=i+10;

	insert into results(first, second) values(i,c);
        insert into results(first, second) values(j,c);

end;
$$
delimiter ;
































