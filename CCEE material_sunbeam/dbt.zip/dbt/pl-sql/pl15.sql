/*
Write a FN, that returns number of years from given date to today.
*/
DELIMITER $$

CREATE FUNCTION FN_YEARDIFF(p_date DATE)
RETURNS INT
NOT DETERMINISTIC
BEGIN
	DECLARE res INT;
	SELECT TIMESTAMPDIFF(YEAR, p_date, NOW()) INTO res FROM DUAL;
	RETURN res;
END;
$$

DELIMITER ;

-- SELECT FN_YEARDIFF('1983-02-28');
-- SELECT ename, hire, FN_YEARDIFF(hire) AS experience FROM EMP;
-- SELECT ename, hire, FN_YEARDIFF(hire) AS experience FROM EMP WHERE FN_YEARDIFF(hire) > 37;









