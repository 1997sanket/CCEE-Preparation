/*
Write a SP which takes dname & loc as its params. Insert into DEPT table with deptno = max deptno + 10.
*/
/*
DELIMITER $$

CREATE PROCEDURE SP_ADD_DEPT(p_dname VARCHAR(40), p_loc VARCHAR(20))
BEGIN
	DECLARE max_deptno INT;
	DECLARE new_deptno INT;
	
	-- SET max_deptno = (SELECT MAX(deptno) FROM DEPT);
	SELECT MAX(deptno) INTO max_deptno FROM DEPT;
	
	SET new_deptno = max_deptno + 10;
	
	INSERT INTO DEPT VALUES(new_deptno, p_dname, p_loc);
END;
$$

DELIMITER ;

*/












































/*
Write a SP which takes dname & loc as its params. Insert into DEPT table with deptno = max deptno + 10.
*/

drop procedure if exists new_4_1_1;
delimiter $$

create procedure new_4_1_1(dname varchar(40), loc varchar(20))
begin

	declare maxim int; 
	
	set maxim=(select max(deptno) from DEPT) +10;

	insert into DEPT(deptno, dname, loc) values( maxim, dname, loc);

end;
$$
delimiter ;





























