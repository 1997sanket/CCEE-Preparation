/*
Write a SP that takes empno as param and print its name along with Rich/Poor remark into RESULTS table.
*/
DELIMITER $$

CREATE PROCEDURE SP_CLASSIFY_EMPS(p_empno INT)
BEGIN
	DECLARE v_ename VARCHAR(40);
	DECLARE v_sal DOUBLE;
	DECLARE v_remark VARCHAR(40) DEFAULT 'Poor ';

	SELECT ename, sal INTO v_ename, v_sal FROM EMP WHERE empno = p_empno;
	
	IF v_sal > 2000 THEN
		SET v_remark = 'Rich ';
	END IF;
	
	INSERT INTO RESULTS(first, second) VALUES(p_empno, CONCAT(v_remark, v_ename));
END;
$$

DELIMITER ;



/*
Write a SP that takes empno as param and print its name along with Rich/Poor remark into RESULTS table.
*/


































