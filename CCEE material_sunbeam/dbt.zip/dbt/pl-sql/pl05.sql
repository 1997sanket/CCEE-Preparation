/*
Write a SP which will take dname as argument and insert its deptno & loc into RESULTS table.
*/
/*
DELIMITER $$

CREATE PROCEDURE SP_GET_DEPT_INFO(p_dname VARCHAR(40))
BEGIN
	DECLARE v_deptno INT;
	DECLARE v_loc VARCHAR(20);

	SELECT deptno, loc INTO v_deptno, v_loc FROM DEPT WHERE dname = p_dname;

	INSERT INTO RESULTS(first, second) VALUES(v_deptno, v_loc);
END;
$$

DELIMITER ;
*/

/*
Write a SP which will take dname as argument and insert its deptno & loc into RESULTS table.
*/

delimiter $$

create procedure new_5(d_name varchar(40))
begin

	declare dept_no int;
	declare location varchar(20);

	set dept_no= (select deptno from DEPT where dname=d_name);
	set location =(select loc from DEPT where dname=d_name);

	insert into results(first, second) values (dept_no, location);
	
end;
$$
delimiter ;





































