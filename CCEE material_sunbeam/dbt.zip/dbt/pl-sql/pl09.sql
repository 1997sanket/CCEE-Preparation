/*
Lower Class -- < 1500
Middle Class -- >= 1500 AND < 2500
Upper Class -- >= 2500
*/

DELIMITER $$

CREATE PROCEDURE SP_CLASSIFY_EMP4(p_empno INT)
BEGIN
	DECLARE v_sal DOUBLE;
	DECLARE v_remark VARCHAR(40);

	SELECT sal INTO v_sal FROM EMP WHERE empno = p_empno;
	
	CASE
	WHEN v_sal < 1500 THEN
		SET v_remark = 'Lower Class';
	WHEN (v_sal >= 1500 AND v_sal < 2500) THEN
		SET v_remark = 'Middle Class';
	ELSE
		SET v_remark = 'Upper Class';
	END CASE;
	
	INSERT INTO RESULTS(first, second) VALUES(p_empno, v_remark);
END;
$$

DELIMITER ;









