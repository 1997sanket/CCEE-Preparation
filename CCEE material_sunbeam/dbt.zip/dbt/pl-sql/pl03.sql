/*DELIMITER $$

CREATE PROCEDURE SP_PARAMS(i INT, j INT, c VARCHAR(40))
BEGIN
	DECLARE k INT;
	DECLARE s VARCHAR(40);
	
	SET k = i + j; -- arithmetic
	SET s = UPPER(c); -- string function

	INSERT INTO RESULTS(first, second) VALUES(k, s);
END;
$$

DELIMITER ;

*/

delimiter $$

create procedure new_3(i int, j int, c varchar(40))

begin

	declare s int;
	declare k varchar(40);

	set s=i+j;
	set k=c;

	insert into results(first, second) values(s,k);

end;
$$
delimiter ;































