/*
When sal of an employee is modified, make its entries into RESULTS table -- old & new salary.
*/

DELIMITER $$

CREATE TRIGGER TRIG_EMP_SAL_UPDATE
AFTER UPDATE ON EMP
FOR EACH ROW
BEGIN
	DECLARE v_empno INT;
	SET v_empno = OLD.empno;
	INSERT INTO RESULTS VALUES(OLD.sal, CONCAT('Old Sal of ', v_empno));
	INSERT INTO RESULTS VALUES(NEW.sal, CONCAT('New Sal of ', v_empno));
END;
$$

DELIMITER ;







