/*
Lower Class -- < 1500
Middle Class -- >= 1500 AND < 2500
Upper Class -- >= 2500
*/

DELIMITER $$

CREATE PROCEDURE SP_CLASSIFY_EMP3(p_empno INT)
BEGIN
	DECLARE v_sal DOUBLE;
	DECLARE v_remark VARCHAR(40);

	SELECT sal INTO v_sal FROM EMP WHERE empno = p_empno;
	
	IF v_sal < 1500 THEN
		SET v_remark = 'Lower class';
	ELSEIF v_sal < 2500 THEN
		SET v_remark = 'Middle class';
	ELSE
		SET v_remark = 'Upper class';
	END IF;
	
	INSERT INTO RESULTS(first, second) VALUES(p_empno, v_remark);
END;
$$

DELIMITER ;







