/*
Q. Add 'Hello World' into RESULTS table.

It is assumed that RESULTS table is already created.
CREATE TABLE RESULTS (first DOUBLE, second VARCHAR(40));
*/

DELIMITER $$

CREATE PROCEDURE SP_HELLO()
BEGIN
	INSERT INTO RESULTS(first, second) VALUES(1, 'Hello World');
END;
$$

DELIMITER ;

-- To submit this procedure:
-- SOURCE /path/to/pl01.sql;

-- To execute this procedure:
-- CALL SP_HELLO();

-- To see result from RESULTS table;
-- SELECT * FROM RESULTS;


/* delimiter $$
create procedure sp_hello()

begin
 	insert into results(first,second) values(1,'hello World');
end;

delimiter ;



