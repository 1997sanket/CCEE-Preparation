/*
Write a SP that accept a number and check if it is prime or not.
It write the result into RESULTS table.
*/

DELIMITER $$

CREATE PROCEDURE SP_PRIME(p_num INT)
BEGIN
	DECLARE i INT DEFAULT 2;
	DECLARE remark VARCHAR(40) DEFAULT 'PRIME';
	
	PRIME: LOOP
		IF i = p_num THEN
			LEAVE PRIME;
		END IF;
	
		IF MOD(p_num, i) = 0 THEN
			SET remark = 'NOT PRIME';
			LEAVE PRIME;
		END IF;
		
		SET i = i + 1;
	END LOOP;

	INSERT INTO RESULTS(first, second) VALUES(p_num, remark);
END;
$$

DELIMITER ;






