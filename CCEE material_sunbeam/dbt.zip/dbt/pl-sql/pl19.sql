/*
Write a SP to add a DEPT.
If PK is duplicated, handle the error.
*/
DELIMITER $$

CREATE PROCEDURE SP_ADD_DEPT4(p_deptno INT, p_dname VARCHAR(40), p_loc VARCHAR(40))
BEGIN
	DECLARE duplicate_entry CONDITION FOR 1062;

	DECLARE EXIT HANDLER FOR duplicate_entry SELECT 'DEPT add failed.' output FROM DUAL;
	
	INSERT INTO DEPT VALUES(p_deptno, p_dname, p_loc);
	
	SELECT 'DEPT is added.' output FROM DUAL;
END;
$$

DELIMITER ;






