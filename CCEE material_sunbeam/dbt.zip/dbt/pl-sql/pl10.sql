/*
Write a SP to insert values (1, 'dac1'), (2, 'dac2'), (3, 'dac3'), ... into RESULTS table.
*/

DELIMITER $$

CREATE PROCEDURE SP_WHILE()
BEGIN
	DECLARE i INT DEFAULT 1;
	DECLARE s VARCHAR(40);

	WHILE i <= 3 DO
		SELECT CONCAT('dac', i) INTO s FROM DUAL;
		INSERT INTO RESULTS VALUES(i, s);
		SET i = i + 1;
	END WHILE;
	
END;
$$

DELIMITER ;

