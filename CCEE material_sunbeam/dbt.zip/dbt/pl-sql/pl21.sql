/*
Write a Procedure using cursor, which read all employee records and insert their no & name with prefix Hello into RESULTS table.
*/

DELIMITER $$

CREATE PROCEDURE SP_CURSOR2()
BEGIN
	DECLARE v_done BOOL DEFAULT FALSE;
	DECLARE v_empno INT;
	DECLARE v_ename VARCHAR(40);
	DECLARE v_cur CURSOR FOR SELECT empno, ename FROM EMP;
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
	
	OPEN v_cur;
	
	READEMP: LOOP
		FETCH v_cur INTO v_empno, v_ename;
		
		IF v_done THEN
			LEAVE READEMP;
		END IF;
		
		INSERT INTO RESULTS VALUES(v_empno, CONCAT('Hello ', v_ename));	
	END LOOP;
	
	CLOSE v_cur;
END;
$$





DELIMITER ;

