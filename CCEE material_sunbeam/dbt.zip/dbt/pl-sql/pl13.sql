/*
Write a SP that takes three args.
1nd arg should be input arg.
2nd arg should be output arg. It should contain twice of 1st arg.
3rd arg should be inout arg. It should contain thrice of 3rd arg.
*/
DELIMITER $$

CREATE PROCEDURE SP_PARAM_TYPES(IN p1 INT, OUT p2 INT, INOUT p3 INT)
BEGIN
	SET p2 = p1 * 2;
	SET p3 = p3 * 3;
END;
$$

DELIMITER ;

-- SET @v2 = 0;
-- SET @v3 = 100;
-- CALL SP_PARAM_TYPES(10, @v2, @v3);
-- SELECT @v2, @v3;

-- SET @v1 = 20;
-- CALL SP_PARAM_TYPES(@v1, @v2, @v3);
-- SELECT @v1, @v2, @v3;




















