/*
Write a SP to add a DEPT.
If PK is duplicated, handle the error.
	- In RESULTS table, add deptno with error message.
*/
DELIMITER $$

drop procedure if exists SP_ADD_DEPT1;

CREATE PROCEDURE SP_ADD_DEPT1(p_deptno INT, p_dname VARCHAR(40), p_loc VARCHAR(40))
BEGIN
	DECLARE EXIT HANDLER FOR 1062
	BEGIN
		INSERT INTO RESULTS VALUES (p_deptno, 'Dept already exist');
	END;	
	
	INSERT INTO DEPT VALUES(p_deptno, p_dname, p_loc);
	
	SELECT 'DEPT is added.' output FROM DUAL;
		-- this line will be skipped, if error occurs.
END;
$$

DELIMITER ;



/*

declare exit handler for 1062
begin
  insert into results(first, second) values(dept_no, 'dept already exists');
end;

 insert into dept values();
 select 'dept added ' output from dual;
*/
