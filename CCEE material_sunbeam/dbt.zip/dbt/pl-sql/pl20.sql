/*
Write a Procedure using cursor, which read 5 employee records and insert their no & name with prefix Hello into RESULTS table.
*/

DELIMITER $$

CREATE PROCEDURE SP_CURSOR1()
BEGIN
	DECLARE i INT DEFAULT 1;
	DECLARE v_empno INT;
	DECLARE v_ename VARCHAR(40);
	DECLARE v_cur CURSOR FOR SELECT empno, ename FROM EMP;
	
	OPEN v_cur;	
	WHILE i <= 5 DO
		FETCH v_cur INTO v_empno, v_ename;
		INSERT INTO RESULTS VALUES(v_empno, CONCAT('Hello ', v_ename));	
		SET i = i + 1;
	END WHILE;
	CLOSE v_cur;
	
END;
$$





DELIMITER ;

