/*
Write a SP to add a DEPT.
If PK is duplicated, handle the error.
	- In RESULTS table, add deptno with error message.
*/
DELIMITER $$

CREATE PROCEDURE SP_ADD_DEPT2(p_deptno INT, p_dname VARCHAR(40), p_loc VARCHAR(40))
BEGIN
	DECLARE err_flag INT DEFAULT 0;
	
	DECLARE CONTINUE HANDLER FOR 1062
	BEGIN
		SET err_flag = 1;
		INSERT INTO RESULTS VALUES (p_deptno, 'Dept already exist');
	END;
	
	INSERT INTO DEPT VALUES(p_deptno, p_dname, p_loc);
	
	IF err_flag = 0 THEN
		SELECT 'DEPT is added.' output FROM DUAL;
	ELSE
		SELECT 'DEPT add failed.' output FROM DUAL;
	END IF;
END;
$$

DELIMITER ;






