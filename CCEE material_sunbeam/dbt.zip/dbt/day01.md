# File
- File - Collection of data or info on secondary storage device.
- File = Contents (Data) + Inforamtion (Metadata)
- File metadata: File control block / i-node (struct)
	- type
	- size
	- timestamps (creation, modification, access)
	- user
	- group
	- permissions
	- where data of file stored (data blocks).
- File data: Stored in data blocks.
- File System: Way of organizing files on disk.
	- Is on a partition of disk.
	- Logically divided into 4 parts.
		1. Boot block -- bootstrap program, bootloader.
		2. Super block -- contains partition information.
		3. Inode list -- contains files inodes
		4. Data blocks -- contains data of files.
	
# DBMS - Database Management Systems
- Generic program that store, manipulate, delete or process records.
- Excel, DBase, Foxpro, ...
- Some sw like excel allow bit of programming -- macros.
- Classfication:
	- Simple: e.g. Excel, ...
	- RDBMS: e.g. **MySQL**, Oracle, ...
	- NoSQL: e.g. **MongoDb**, ...
	
# RDBMS - Relational DBMS
- Designed for handling fixed format data - structured data.
- Data is organized logically into tables, rows & columns.
- e.g. MySQL, Oracle, SQLite, ...

## DBMS vs RDBMS
- Record | Row
- Fields | Columns, Attributes
- File | Table
- Relations must be managed programmatically | Built-in Rel mgmt.
- Lot of programming | Data processing is built-in (DB engine).
- Heavy network traffic | Less network traffic (Only a record).
- File level lock | Table level OR Row level locking.
- Client processing | Server processing
- Slow processing | Faster processing
- Small data | Works well for big data (100s of GB)
- Single user | Multi users
- No networking support | Network based.
- Not distributed | Modern dbs are distributed.
- No security | Secure: OS, Db auth, Table, Row

## RDBMS:
- DB2 (IBM), CICS, TELON -- mainframe 
- Oracle -- Enterprise DB, Commerical.
- MS SQL Server -- Enterprise DB, Commerical, Windows only.
- PostgresSQL -- Open Source DB, ...
- Sybase -- Taken over by SAP.
- Informix -- Very fast, Need knowledge of Assembly langauge.
- MSAccess -- RDBMS, single user.
- SQLite -- RDBMS, single user.
- MySQL -- Open Source DB, Enterprise DB, Partially Commerical.
- MariaDb -- Clone of MySQL, Fully open-source.

# MySQL:
- 1995: Michel -- Open Source Db -- "Myia".
- 2008: Taken by Sun Microsystem.
- 2010: Sun Microsystem Taken by Oracle.
- MySQL commnity edition is free.

# MariaDb:
- Fully open source.

# SQL - Structured Query Language
- (IBM) RQBE -- Relational Query By Example.
- Progamming language for RDBMS.
- ANSI standardized -- 1986 ... 2016.
- Modern Db support ANSI SQL + Extended SQL.
- Declarative Language.

# MySQL Installation
- MySQL version 8.0.x
- Command:
	- sudo apt-get install net-tools mysql-community-server mysql-community-client
		- admin (root) password: "manager".
		- password: legacy password.
	- sudo systemctl status mysql
	- sudo netstat -tlnp
		- 3306 port -- mysqld
	- sudo systemctl stop mysql
	- sudo systemctl start mysql
		
# Using MySQL.
- MySQL server - mysqld - Doesn't have UI.
- MySQL clients
	- mysql cli - Command line interface
	- mysql workbench - GUI
	- phpmyadmin - Web based interface
```
cmd> mysql -u root -p
```
- MySQL queries

```SQL
CREATE USER 'dac'@'localhost' IDENTIFIED BY 'dac';

CREATE DATABASE dacdb;

GRANT ALL PRIVILEGES ON dacdb.* TO 'dac'@'localhost';

FLUSH PRIVILEGES;

QUIT
```

```
cmd> mysql -u dac -p
cmd> mysql -u dac -h localhost -p
cmd> mysql -u dac -h localhost -p
cmd> mysql -u dac -pdac
```

```SQL
SHOW DATABASES;

USE dacdb;

SHOW TABLES;

CREATE TABLE STUDENTS (roll INT, name VARCHAR(40), marks DOUBLE);

DESCRIBE STUDENTS;

SELECT * FROM STUDENTS;

INSERT INTO STUDENTS VALUES (1, 'Nitin', 34.45);
INSERT INTO STUDENTS VALUES (2, 'Sarang', 37.34), (3, 'Nilesh', 33.12), (4, 'Sandeep', 34.56);

SELECT * FROM STUDENTS;

QUIT;
```

```
cmd> mysql -u root -p
```

```SQL
CREATE DATABASE classwork;

GRANT ALL PRIVILEGES ON classwork.* TO 'dac'@'localhost';

FLUSH PRIVILEGES;

QUIT;
```

```
cmd> mysql -u dac -p
```

```SQL
SOURCE /path/to/classwork-db.sql;

SELECT * FROM BOOKS;

... other commands

QUIT;
```

