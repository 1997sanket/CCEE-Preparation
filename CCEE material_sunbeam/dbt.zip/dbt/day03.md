# DELETE FROM TABLE vs TRUNCATE TABLE.
-----------------------
| DELETE | TRUNCATE |
| ------ | ---------|
| All rows are deleted from table | All rows are deleted from table |
| DML query | DDL query |
| Can be rollback if part of tx | Cannot be rollback |
| Mark records as deleted in file. File size not changed. | File size is truncated. |
| Slower. | Faster. |

# DROP vs TRUNCATE TABLE.
| DROP   | TRUNCATE |
| ------ | ---------|
| DDL query | DDL query |
| Table data & schema is deleted. | Only data is deleted. |
| Table file is deleted. | Table file size is truncated. |

# UPDATE
* When a record is edited - if a field size (e.g. VARCHAR) is reduced, the record is updated inline. The remaining space is unused (but not deleted).
* When a record is edited - if a field size (e.g. VARCHAR) is increased, record size cannot grow in place. In this case a new record is allocated with new required size and then record is edited. This increases fragmentation on disk.

# GRANT & REVOKE
* RDBMS has built-in security. It also provides db level, table level, row level, object level security.
* It is achieved using DCL i.e. GRANT & REVOKE.
* GRANT is to give privileges.
* REVOKE is to withdraw privileges.

## Privileges Types:
* System privileges/Global privileges:
	- In MySQL, *.* is used to give global privilege.
	- Privileges to create new db, new table, repair db, config db are global.
	- By default all privileges are accessible to main/administrator user of db.
	- In MySQL, "root" user is db admin and it is created during installation of MySQL.
	- "root" user can give these permissions to other users.
* Object privileges:
	- dbname.objname is used to give object privilege.
	- The objects can be tables, procedures, ...
	- Table privileges -- INSERT, UPDATE, DELETE, SELECT.
	- Procedure privileges -- EXECUTE.

## Permission Types:
* USAGE -- No privilege.
* SELECT, INSERT, UPDATE, DELETE -- rows in table.
* CREATE -- USER, DATABASE, TABLE, PROCEDURE, INDEX.
* DROP -- DATABASE, TABLE, PROCEDURE, INDEX.
* ALL -- Most of the permissions related to data & structure. But no permissions related to privileges. Cannot give permissions to other users on your db.
* GRANT OPTION -- This permission allows giving privileges to other users. You can only give those privileges which you have.

* Few permissions may differ with db vendor.

## Permission related basic queries:
```SQL
SELECT USER();

SELECT DATABASE();

SHOW DATABASES;

SHOW GRANTS;

FLUSH PRIVILEGES;

SHOW GRANTS FOR dac@localhost;

SELECT user, host FROM mysql.user;

```

## GRANT permsissions

```SQL
GRANT CREATE, DROP ON *.* TO nilesh@localhost;
-- root

SHOW GRANTS FOR nilesh@localhost;
-- root

GRANT ALL PRIVILEGES ON hr.* TO nilesh@localhost WITH GRANT OPTION;
-- root

GRANT SELECT, INSERT, UPDATE, DELETE ON hr.* TO dac@localhost ;
-- nilesh

GRANT SELECT (JOB_ID, JOB_TITLE) ON hr.jobs TO dmc@localhost;
-- nilesh

```

## REVOKE permissions

```SQL
REVOKE ALL PRIVILEGES ON classwork.* FROM dac@localhost;

```

# DUAL table
* Historically it is a temp in-memory dummy table created by oracle. It was table of two dummy rows. Hence name given was "dual".
* Table is changed to single row, single column table.
* A special table available to all users.
* Used for doing arbitrary calculations or executing some system functions.
* DUAL table is then adopted by ANSI and hence supported in most of RDBMS.

```SQL
SELECT 2 + 3 * 4 FROM DUAL;

SELECT ROUND(2.12345, 4) FROM DUAL;

SELECT USER(), DATABASE() FROM DUAL;

SELECT NOW(), SYSDATE() FROM DUAL;
```

* In MySQL, DUAL table is supported, but is optional.

```SQL
SELECT 2 + 3 * 4;

SELECT ROUND(2.12345, 4);

SELECT USER(), DATABASE();

SELECT NOW(), SYSDATE();
```

# SQL Functions
* Many functions are ANSI standardized. But few functions are db specific.

## Function Help
``` SQL
HELP Functions;

HELP String Functions;

HELP CONCAT;

HELP Numeric Functions;
```

### String Functions
```
SELECT CONCAT('Sunbeam', 'Infotech');

SELECT CONCAT('Sunbeam', ' ', 'Infotech');

SELECT CONCAT(NAME, ' -- ', AUTHOR) FROM BOOKS;

SELECT UPPER(NAME) FROM BOOKS;

UPDATE BOOKS SET NAME=UPPER(NAME);

--SUBSTRING(str,pos);
SELECT SUBSTRING('sunbeam', 4);

SELECT SUBSTRING('sunbeam', -2);

--SUBSTRING(str,pos,len);
SELECT SUBSTRING('sunbeam', 1, 3);

SELECT SUBSTRING('sunbeam', 4, 2);

SELECT SUBSTRING('sunbeam', -6, 2);

SELECT SUBSTRING('sunbeam', 4, 1);

SELECT SUBSTRING('sunbeam', 4, 0);

SELECT SUBSTRING('sunbeam', 4, -1);

SELECT SUBSTRING('sunbeam', 1, 1);

SELECT ename FROM EMP WHERE SUBSTRING(ename, 1, 1) BETWEEN 'C' AND 'T';

SELECT SUBSTRING(SUBJECT, 1, 3) FROM BOOKS;

SELECT TRIM(SUBJECT) FROM BOOKS;

INSERT INTO BOOKS(ID, SUBJECT) VALUES (10001, '                 abcd               ');

```

## Single Row Functions
* Operate on one row data at a time.

### Numeric Functions

```SQL

SELECT 1.2356, -1.2356, FLOOR(1.2356), FLOOR(-1.2356);

SELECT 1.2356, -1.2356, CEIL(1.2356), CEIL(-1.2356);

SELECT 1.2356, -1.2356, ROUND(1.2356,2), ROUND(-1.2356,2);

SELECT ROUND(123.456,2), ROUND(123.456,0), ROUND(123.456,-2);

SELECT ROUND(876.456,2), ROUND(876.456,0), ROUND(876.456,-2);

```

### Date & Time Functions

```SQL

SELECT NOW(), SLEEP(5), SYSDATE();

SELECT hire, ADDDATE(hire, 90) FROM EMP LIMIT 3;

SELECT hire, DATE_ADD(hire, INTERVAL 5 years) FROM EMP LIMIT 3;

SELECT DATEDIFF('1980-12-17', '1981-12-03');

SELECT hire, YEAR(hire), MONTH(hire), DAY(hire) FROM EMP LIMIT 3;

SELECT hire, DATE_FORMAT(hire, '%d-%M-%Y') FROM EMP LIMIT 3;
```

### List Functions
```SQL
SELECT GREATEST(12, 67, 23, 89, 45);

SELECT GREATEST('Abcdefg', 'Pqrs', 'Xyz');

SELECT LEAST(12, 67, 23, 89, 45);

SELECT LEAST('Abcdefg', 'Pqrs', 'Xyz');

SELECT NAME, PRICE, LEAST(PRICE, 900.00) FROM BOOKS;

```

### NULL Related Functions
* NULL is a special value for any column -- represent that value is absent.
* NULL value is inserted into records when certain value is not applicable or not yet available.
* No operations can be performed on NULL values i.e. arithmetic/relational operation, single row functions, multi row functions.

```SQL
INSERT INTO BOOKS(ID, NAME) VALUES (10001, 'Atlas Shrugged');

INSERT INTO BOOKS(ID, NAME, PRICE) VALUES (10001, 'The Fountainhead', NULL);

SELECT * FROM EMP WHERE comm = NULL;

SELECT * FROM EMP WHERE comm <=> NULL;

SELECT * FROM EMP WHERE comm IS NULL;

SELECT * FROM EMP WHERE comm IS NOT NULL;

SELECT sal, comm, sal + comm FROM EMP;

SELECT sal, comm, IFNULL(comm, 0), sal + IFNULL(comm, 0) FROM EMP;

```

## Multi-Row functions
- Operate on multiple rows. Also called as Group functions or Aggregregate functions.
- e.g. SUM(), COUNT(), MAX(), MIN(), AVG(), STDEV(), ...

```SQL
SELECT SUM(sal) FROM EMP;

SELECT COUNT(sal), SUM(sal), AVG(sal), MIN(sal), MAX(sal) FROM EMP;

SELECT COUNT(comm), SUM(comm), AVG(comm) FROM EMP;

SELECT COUNT(IFNULL(comm,0)), SUM(IFNULL(comm,0)), AVG(IFNULL(comm,0)) FROM EMP;

SELECT ename, SUM(sal) FROM EMP;
-- not allowed

SELECT LOWER(ename), SUM(sal) FROM EMP;
-- not allowed

SELECT * FROM EMP WHERE sal > AVG(sal);
-- not allowed

SELECT MAX(SUM(sal)) FROM EMP;
-- not allowed

```

# GROUP BY
* To group multiple rows based on some col value and process (aggregate) its data.

```SQL
SELECT SUM(sal) FROM EMP GROUP BY deptno;

SELECT deptno, SUM(sal) FROM EMP GROUP BY deptno;

SELECT deptno, COUNT(empno), SUM(sal), AVG(sal), MIN(sal), MAX(sal) FROM EMP GROUP BY deptno;

SELECT job, AVG(sal) FROM EMP GROUP BY job;

SELECT deptno, job, COUNT(empno) FROM EMP GROUP BY deptno, job;

SELECT deptno, job, SUM(sal) FROM EMP GROUP BY deptno, job ORDER BY deptno, job;

SELECT COUNT(empno) FROM EMP GROUP BY deptno;
-- ok

SELECT deptno, COUNT(empno) FROM EMP GROUP BY deptno;
-- ok

SELECT job, COUNT(empno) FROM EMP GROUP BY deptno;
-- error

SELECT job, deptno, COUNT(empno) FROM EMP GROUP BY deptno, job;
-- ok

SELECT deptno, SUM(sal) FROM EMP
WHERE deptno IN (10, 30)
GROUP BY deptno;

HELP SELECT;

SELECT deptno, SUM(sal) AS total FROM EMP
GROUP BY deptno
ORDER BY total
LIMIT 1;

SELECT deptno, SUM(sal) AS total FROM EMP
GROUP BY deptno
HAVING SUM(sal) > 10000;
-- okay

SELECT deptno, SUM(sal) AS total FROM EMP
GROUP BY deptno
HAVING deptno = 20;
-- allowed, but slow

SELECT deptno, SUM(sal) AS total FROM EMP
WHERE deptno=20
GROUP BY deptno;
-- okay

-- Q. Find the dept that spend max on clerk salaries.
SELECT deptno, SUM(sal)
FROM EMP
GROUP BY deptno;

SELECT deptno, SUM(sal) total
FROM EMP
WHERE job='CLERK'
GROUP BY deptno
ORDER BY total DESC
LIMIT 1;

-- Q. Find the dept that spend more than 1500 on clerk salaries.
SELECT deptno, SUM(sal) total
FROM EMP
WHERE job='CLERK'
GROUP BY deptno
HAVING SUM(sal) > 1500;

```

# Sub-Queries
* Query within query.
* Usually SELECT Query within SELECT query.
* For each row of outer query, inner query is executed once. This slow down speed of execution.

## Single row sub-query
* Sub-query that is returning single row.

```SQL
-- Q. Find all employees whose salary is greater than avg sal of employees.

SELECT ename, sal FROM EMP ORDER BY sal DESC;

SELECT AVG(sal) FROM EMP;

SELECT ename, sal FROM EMP WHERE sal > 2073.214286;

SELECT ename, sal FROM EMP WHERE sal > (SELECT AVG(sal) FROM EMP);
```

## Multi row sub-query
* Sub-query that is returning multiple rows.

```SQL
-- Q. Find all dept which contains employees.
SELECT * FROM DEPT;

SELECT DISTINCT(deptno) FROM EMP;

SELECT * FROM DEPT WHERE deptno IN (10, 20, 30);

SELECT * FROM DEPT
WHERE deptno IN (SELECT DISTINCT(deptno) FROM EMP);

SELECT * FROM DEPT
WHERE deptno = ANY(SELECT DISTINCT(deptno) FROM EMP);

-- Q. Find all employees whose sal is more than sal of employees in dept 20.

SELECT deptno, sal FROM EMP ORDER BY deptno, sal DESC;

SELECT * FROM EMP 
WHERE sal > ALL(SELECT sal FROM EMP WHERE deptno=20);

SELECT * FROM EMP
WHERE sal > (SELECT MAX(sal) FROM EMP WHERE deptno=20);

```

## Correlated Sub-Queries
* When row of outer of query is used for comparision inside inner query, then such query is called as "correlated sub-query".

```SQL
SELECT d.dname FROM DEPT d
WHERE EXISTS
(SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);

SELECT d.dname FROM DEPT d
WHERE NOT EXISTS
(SELECT e.deptno FROM EMP e WHERE e.deptno = d.deptno);
```


































