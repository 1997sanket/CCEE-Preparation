```
Nilesh Ghule
M.Sc. Electronics
```
# Ubuntu Installation
## Prerequisites
#### Computer
* Computer Hardware: Motherboard + Disk + Keyboard + Mouse + Monitor
* Motherboard: CPU + Chipset + Base ROM
* Base ROM: Set of programs fixed into hardware -- Firmware.
* Firmware: Burned into ROM by Motherboad manufacturer.
* IBM + MS --> Motherboard --> Firmware --> BIOS
	- Disk size: max 2 TB.
	- Disk Partitioning Scheme: MBR (Master Boot Record)
		- Max 4 **Primary partitions**
		- One of the primary partition can be made as **Extended**
		- Extended partition can contain multiple **Logical partitions**
	- No security
* Intel + HP --> Motherboard --> Firmware --> EFI --> EFI2.0 (UEFI)
	- Disk size: max 8 ZB.
	- Disk Partitioning Scheme: GPT (GUID Partition Table)
		- Max 128 Primary Partitions
		- Recovery options
	- Security in built-in
	- OEM tie-up
	
#### Know your computer
* Computer
	- Windows is pre-installed.
	- One empty drive of 80 GB or more.
	- Delete that drive from Windows Disk Management -- Free space.
* BIOS
	- Disk: AHCI (SATA) /Legacy (PATA)
	- Boot Mode: UEFI / Legacy
	- Secure Boot: Enabled / Disabled
	- Boot Device Priority
	- Boot Device Selection
* Disk Partitioning Scheme: MBR / GPT

#### Installation Steps
* Boot from ubuntu Bootable CD/pen-drive.
* Custom partitioning (Something Else).
	- Partition 1: root partition "/" -- 80 GB
	- Partition 2: swap partition -- 4 GB
		- Virtual memory -- swap area.
		- When RAM is full, inactive processes can be temp shifted to area of disk, called as swap area.
		- Swap area: Swap partition OR Swap file.
		- Windows: Swap file - C:\pagefile.sys
		- Linux: Swap paritition - to be created during installation
		
#### Ubuntu softwares installation
* Way1: 
	- All ubuntu softwares are stored in their online repository.
	- Steps for installtion from there:
		1. Connect to high-speed internet.
		2. Open terminal.
		3. cmd> sudo apt-get update
			- connect to online repo & collect metadata.
		4. cmd> sudo apt-get install openjdk-8-jdk apache2 mysql-server ...
		
* Way2: (at Sunbeam)
	- All required softwares are copied into offline repository **subuntu**.
	- An installation script is created containing all commands required for installtion **install.sh**.
	- Steps for installtion from there:
		1. Open terminal.
		2. Go to the directory in which install.sh is kept.
		3. cmd> sudo ./install.sh
		
#### Bootloader
* Firmware
	- During booting a program (Bootstrap loader) from firmware look for bootable device.
	- It follows "Boot Device Priority".
* Bootable device
	- Can be CD/DVD, Pen-drive or hard-disk.
	- It contains "Bootstrap program", in its first sector (512 bytes).
* Bootloader
	- Can provide option to select OS to be booted.
	- As per user selection it starts corresponding bootstrap program.
* Bootstrap program
	- Can load the kernel in main memory.
	- Different for each OS.
* Kernel
	- Core OS
	- Once kernel is loaded, OS is said to be "booted".
* Booting Sequence
	- Bootstrap loader -> Bootloader -> Bootstrap -> Kernel
* Different bootloader
	- Windows Vista+ -- bootmgr (bcd)
	- Linux -- grub (grub.cfg)
* GrUB: Grand Unified Bootloader
	- Current version: grub 2.0
	- grub config file (/boot/grub2/grub.cfg)

# Linux
### Windows File System
```
My Computer
	|- E:
	|- D:
	|- C:
		|- Windows
		|- Program Files
		|- Users
			|- sunbeam (user profile)
				|- Documents
				|- Desktop
				|- Downloads
				|- Pictures
				|- ...
```
### Linux File System
```
(root) /
	|- boot -- kernel (vmlinuz) & bootloader (grub)
	|- bin -- basic commands
	|- sbin -- admin commands
	|- lib -- libraries (.so) & device drivers (.ko)
	|- usr -- installed programs
	|- opt -- optional softwares
	|- srv -- server softwares (ftp, web servers, ...)
	|- var -- system logs
	|- dev -- related to device drivers
	|- sys -- related to device drivers
	|- proc -- related to device drivers
	|- etc -- config files
	|- root -- admin/super-user files
	|- home
		|- sunbeam (user's home directory)
			|- Documents
			|- Desktop
			|- Downloads
			|- Pictures
			|- ...	
```

# GIT
#### Get daily classwork from GIT.
* Install git:
	- sudo apt-get install git
* Copy data -- day1 of a new module:
	- Open terminal.
	- Go to the directory where you want to copy data.
	- cmd> git clone http://172.0.0.201/dac/dbt.git
		- Will create a directory **dbt** into your current dir.
		- Copy all data from git server.
* Copy data -- rest of the module:
	- Open terminal.
	- Go to the **dbt** directory.
	- cmd> git pull

















